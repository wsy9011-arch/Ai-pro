import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const PLANS = {
  starter: {
    amount: 29900,
    plan: "starter",
    remainingCount: 30,
    unlimited: false,
  },
  pro: {
    amount: 49900,
    plan: "pro",
    remainingCount: 100,
    unlimited: false,
  },
} as const;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const paymentKey = String(body.paymentKey || "");
    const orderId = String(body.orderId || "");
    const amount = Number(body.amount || 0);

    if (!paymentKey || !orderId || !amount) {
      return NextResponse.json(
        { message: "결제 승인에 필요한 정보가 없습니다." },
        { status: 400 }
      );
    }

    const orderMatch = orderId.match(
      /^quote_(starter|pro)_([0-9a-fA-F-]{36})_([A-Za-z0-9-]+)$/
    );

    if (!orderMatch) {
      return NextResponse.json(
        { message: "올바르지 않은 주문번호입니다." },
        { status: 400 }
      );
    }

    const planKey = orderMatch[1] as keyof typeof PLANS;
    const userId = orderMatch[2];
    const planInfo = PLANS[planKey];

    if (amount !== planInfo.amount) {
      return NextResponse.json(
        { message: "결제 금액이 상품 금액과 일치하지 않습니다." },
        { status: 400 }
      );
    }

    const tossSecretKey = process.env.TOSS_SECRET_KEY;

    if (!tossSecretKey) {
      return NextResponse.json(
        {
          message:
            "TOSS_SECRET_KEY 환경변수가 설정되지 않았습니다.",
        },
        { status: 500 }
      );
    }

    const supabaseUrl =
      process.env.NEXT_PUBLIC_SUPABASE_URL;

    const supabaseServiceRoleKey =
      process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return NextResponse.json(
        {
          message:
            "Supabase 서버 환경변수가 설정되지 않았습니다.",
        },
        { status: 500 }
      );
    }

    const encodedSecretKey = Buffer.from(
      `${tossSecretKey}:`
    ).toString("base64");

    const tossResponse = await fetch(
      "https://api.tosspayments.com/v1/payments/confirm",
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${encodedSecretKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          paymentKey,
          orderId,
          amount,
        }),
      }
    );

    const tossResult = await tossResponse.json();

    if (!tossResponse.ok) {
      return NextResponse.json(
        {
          message:
            tossResult?.message ||
            "토스 결제 승인에 실패했습니다.",
        },
        { status: tossResponse.status }
      );
    }

    const supabaseAdmin = createClient(
      supabaseUrl,
      supabaseServiceRoleKey,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    const { error: planError } =
      await supabaseAdmin
        .from("user_plans")
        .upsert(
          {
            user_id: userId,
            plan: planInfo.plan,
            remaining_count:
              planInfo.remainingCount,
            unlimited: planInfo.unlimited,
            updated_at:
              new Date().toISOString(),
          },
          {
            onConflict: "user_id",
          }
        );

    if (planError) {
      console.error(
        "PLAN UPDATE ERROR:",
        planError
      );

      return NextResponse.json(
        {
          message:
            "결제는 승인됐지만 이용권 적용에 실패했습니다. 관리자에게 문의해주세요.",
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      plan: planInfo.plan,
      remainingCount:
        planInfo.remainingCount,
      paymentKey: tossResult.paymentKey,
    });
  } catch (error) {
    console.error(
      "TOSS CONFIRM ERROR:",
      error
    );

    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? error.message
            : "결제 승인 중 오류가 발생했습니다.",
      },
      { status: 500 }
    );
  }
}