import OpenAI from "openai";
import { NextResponse } from "next/server";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

type PriceItem = {
  item_name: string;
  unit: string;
  unit_price: number;
  category?: string | null;
  description?: string | null;
};

type AiMatchedItem = {
  itemName?: string;
  quantity?: number;
};

export async function POST(request: Request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        {
          error: "OPENAI_API_KEY가 설정되지 않았습니다.",
        },
        { status: 500 }
      );
    }

    const body = await request.json();

    const {
      customerName,
      region,
      serviceType,
      inquiry,
      businessType,
      priceItems = [],
    } = body as {
      customerName?: string;
      region?: string;
      serviceType?: string;
      inquiry?: string;
      businessType?: string;
      priceItems?: PriceItem[];
    };

    if (!inquiry?.trim()) {
      return NextResponse.json(
        {
          error: "고객 문의 내용이 필요합니다.",
        },
        { status: 400 }
      );
    }

    if (!businessType?.trim()) {
      return NextResponse.json(
        {
          error: "업종 정보가 없습니다. 설정에서 업종을 확인해주세요.",
        },
        { status: 400 }
      );
    }

    // 프론트에서 전달받은 업체 단가표 정리
    const safePriceItems: PriceItem[] = Array.isArray(priceItems)
      ? priceItems
          .filter(
            (item) =>
              item &&
              typeof item.item_name === "string" &&
              typeof item.unit === "string" &&
              Number.isFinite(Number(item.unit_price))
          )
          .map((item) => ({
            item_name: item.item_name.trim(),
            unit: item.unit.trim(),
            unit_price: Number(item.unit_price),
            category: item.category || null,
            description: item.description || null,
          }))
      : [];

      const businessTypeLabel =
  businessType === "interior_film"
    ? "인테리어필름"
    : businessType;
    const priceListText =
      safePriceItems.length > 0
        ? safePriceItems
            .map(
              (item, index) =>
                `${index + 1}. 항목명: ${item.item_name} | ` +
                `단위: ${item.unit} | ` +
                `단가: ${item.unit_price}원 | ` +
                `분류: ${item.category || "없음"} | ` +
                `설명: ${item.description || "없음"}`
            )
            .join("\n")
        : "등록된 단가표 없음";

    /*
      AI 역할
      - 현재 업체 업종을 이해
      - 고객 문의 분석
      - 등록된 단가표 항목과 매칭
      - 수량 추출
      - 가격 계산은 하지 않음
    */
    const analysisPrompt = `
당신은 여러 업종의 사업자가 사용하는 AI 견적 분석 시스템입니다.

현재 이 업체의 업종은 다음과 같습니다.

[현재 업체 업종]
${businessType}

업종의 특성과 일반적인 작업 용어를 이해한 상태에서
고객 문의내용을 분석하세요.

예를 들어 현재 업종이 "인테리어필름"이라면
싱크대, 문짝, 샷시, 방문, 현관문, 붙박이장,
신발장, 몰딩 등의 표현을 인테리어필름 시공 관점에서
이해해야 합니다.

하지만 가격은 절대 임의로 추측하면 안 됩니다.

가격 계산에 사용할 수 있는 항목은 오직 아래
"업체 등록 단가표"에 존재하는 항목뿐입니다.

[고객 정보]

고객명: ${customerName || "미입력"}
지역: ${region || "미입력"}
고객 선택 서비스: ${serviceType || "미입력"}

[업체 등록 단가표]

${priceListText}

[고객 문의]

${inquiry}

중요 규칙:

1. 가격을 직접 계산하지 마세요.

2. matchedItems의 itemName은 반드시
   업체 등록 단가표에 실제 존재하는 정확한 item_name만
   사용하세요.

3. 단가표에 없는 항목을 새로 만들지 마세요.

4. 고객 문의에 수량이 명확하게 적혀 있을 때만
   quantity를 반환하세요.

5. 고객이 말하지 않은 수량을 임의로 추측하지 마세요.

6. 예:
   "싱크대 문짝 10개 필름 시공하고 싶어요."
   라고 문의했고 단가표에 "싱크대 문짝"이 있다면
   quantity는 10입니다.

7. 여러 항목과 수량이 명확하면
   matchedItems 배열에 모두 넣으세요.

8. 문의 표현과 단가표 표현이 조금 다르더라도
   의미가 명확하게 동일한 경우에는
   등록된 정확한 item_name으로 매칭할 수 있습니다.

9. 단가표와 일치하는 항목이 없거나
   수량을 알 수 없다면 matchedItems는 빈 배열로 반환하세요.

10. workDescription에는 실제 고객 문의를 바탕으로
    작업 내용을 자연스럽고 간결하게 정리하세요.

11. customerReply에는 고객에게 바로 보낼 수 있는
    자연스러운 한국어 존댓말 답변을 작성하세요.

12. JSON 이외의 문장은 절대 출력하지 마세요.

반드시 다음 JSON 구조로만 반환하세요.

{
  "matchedItems": [
    {
      "itemName": "업체 단가표의 정확한 항목명",
      "quantity": 1
    }
  ],
  "workDescription": "고객 문의를 바탕으로 한 작업 내용",
  "customerReply": "고객에게 보낼 자연스러운 존댓말 답변"
}
`;

    const response = await openai.responses.create({
      model: "gpt-5-mini",
      input: analysisPrompt,
    });

    const text = response.output_text;

    if (!text) {
      throw new Error("AI 응답이 비어 있습니다.");
    }

    const cleanedText = text
      .trim()
      .replace(/^```json\s*/i, "")
      .replace(/^```\s*/i, "")
      .replace(/\s*```$/i, "");

    const aiResult = JSON.parse(cleanedText);

    const matchedItems: AiMatchedItem[] = Array.isArray(
      aiResult.matchedItems
    )
      ? aiResult.matchedItems
      : [];

    /*
      가격 계산은 AI가 아니라 서버에서 수행
    */
    let calculatedTotal = 0;

    const calculationDetails: string[] = [];

    const normalizeItemName = (value: string) =>
      value.replace(/\s+/g, "").toLowerCase().trim();

    for (const matched of matchedItems) {
      const itemName =
        typeof matched.itemName === "string"
          ? matched.itemName.trim()
          : "";

      const quantity = Number(matched.quantity);

      if (
        !itemName ||
        !Number.isFinite(quantity) ||
        quantity <= 0
      ) {
        continue;
      }

      // AI가 반환한 항목을 실제 등록 단가표와 다시 검증
      const registeredItem = safePriceItems.find(
        (item) =>
          normalizeItemName(item.item_name) ===
          normalizeItemName(itemName)
      );

      if (!registeredItem) {
        continue;
      }

      const lineAmount = registeredItem.unit_price * quantity;

      calculatedTotal += lineAmount;

      const displayUnit = registeredItem.unit.endsWith("당")
  ? registeredItem.unit.slice(0, -1)
  : registeredItem.unit;

calculationDetails.push(
  `${registeredItem.item_name} ${quantity}${displayUnit} × ` +
    `${registeredItem.unit_price.toLocaleString("ko-KR")}원 = ` +
    `${lineAmount.toLocaleString("ko-KR")}원`
);
    }

    /*
      기존 EstimateManager 구조 유지

      현재 단가표 계산 금액은 우선 laborCost에 저장.
      추후 단가표에 비용유형을 추가하면
      자재비 / 인건비 / 기타비용으로 자동 분리 가능.
    */
    const materialCost = 0;
    const laborCost = calculatedTotal;
    const otherCost = 0;

    const totalAmount =
      materialCost + laborCost + otherCost;

    let workDescription =
      typeof aiResult.workDescription === "string"
        ? aiResult.workDescription.trim()
        : "";

    if (calculationDetails.length > 0) {
      workDescription = [
        workDescription,
        "",
        `[업종: ${businessTypeLabel}]`,
        "[업체 등록 단가 기준]",
        ...calculationDetails,
      ]
        .filter(Boolean)
        .join("\n");
    } else {
      workDescription = [
        workDescription,
        "",
        `[업종: ${businessType}]`,
        "현재 문의내용만으로 업체 단가표를 이용한 자동 계산이 어렵습니다.",
        "견적 항목과 수량을 추가로 확인해주세요.",
      ]
        .filter(Boolean)
        .join("\n");
    }

    let customerReply =
      typeof aiResult.customerReply === "string"
        ? aiResult.customerReply.trim()
        : "";

    if (totalAmount > 0) {
      customerReply = [
        customerReply,
        "",
        `현재 확인된 내용과 등록 단가 기준 예상 견적은 ${totalAmount.toLocaleString(
          "ko-KR"
        )}원입니다.`,
        "실제 현장 상태와 작업 범위에 따라 최종 견적은 달라질 수 있습니다.",
      ]
        .filter(Boolean)
        .join("\n");
    } else {
      customerReply = [
        customerReply,
        "",
        "정확한 견적을 위해 작업 수량이나 현장 정보를 조금 더 확인해야 합니다.",
      ]
        .filter(Boolean)
        .join("\n");
    }

    return NextResponse.json({
      businessType,
      workDescription,
      materialCost,
      laborCost,
      otherCost,
      totalAmount,
      customerReply,

      // 개발 중 확인용
      matchedItems,
      calculationDetails,
    });
  } catch (error) {
    console.error("AI ESTIMATE ERROR:", error);

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "AI 견적 생성 중 오류가 발생했습니다.",
      },
      { status: 500 }
    );
  }
}