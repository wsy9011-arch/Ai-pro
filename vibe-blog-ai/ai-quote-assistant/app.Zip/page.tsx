"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

import CustomerManager from "@/components/CustomerManager";
import EstimateManager from "@/components/EstimateManager";
import ConsultationManager from "@/components/ConsultationManager";
import ContractManager from "@/components/ContractManager";
import UnpaidManager from "@/components/UnpaidManager";
import SalesManager from "@/components/SalesManager";
import SettingsManager from "@/components/SettingsManager";
import PriceItemManager from "@/components/PriceItemManager";

const BUSINESS_TYPE_LABELS: Record<string, string> = {
  interior_film: "인테리어필름",
  wallpaper_flooring: "도배·장판",
  cleaning: "청소",
  air_conditioner: "에어컨",
  moving: "이사",
  demolition: "철거",
  auto_repair: "자동차 정비",
  sign_printing: "간판·인쇄",
  window_screen: "방충망·샷시",
  field_repair: "출장수리",
  plumbing: "설비·배관",
  electrical: "전기",
  painting: "도장·페인트",
  other: "기타",
};

type MenuItem = {
  icon: string;
  name: string;
  description: string;
};

function getMenus(businessType: string): MenuItem[] {
  const label =
    BUSINESS_TYPE_LABELS[businessType] || "내 업종";

  return [
    {
      icon: "🏠",
      name: "홈",
      description: `${label} 업무를 한곳에서 관리하세요.`,
    },
    {
      icon: "👥",
      name: "고객 관리",
      description: `${label} 고객 문의와 고객 정보를 관리하세요.`,
    },
    {
      icon: "🧾",
      name: "견적 관리",
      description: `${label} 등록 단가를 기준으로 AI 견적을 만들어보세요.`,
    },
    {
      icon: "💬",
      name: "AI 상담",
      description: `${label} 고객에게 보낼 상담 답변을 빠르게 만들어보세요.`,
    },
    {
      icon: "📋",
      name: "계약 관리",
      description: `${label} 견적부터 계약 완료까지 관리하세요.`,
    },
    {
      icon: "💰",
      name: "매출 관리",
      description: `${label} 견적과 계약 매출을 확인하세요.`,
    },
    {
      icon: "💳",
      name: "단가 관리",
      description: `내 ${label} 서비스 단가만 등록하고 관리하세요.`,
    },
    {
      icon: "⚙️",
      name: "설정",
      description: "업체정보와 계정을 관리하세요.",
    },
  ];
}

export default function Home() {
  const router = useRouter();
  const [authChecking, setAuthChecking] = useState(true);
  const [activeMenu, setActiveMenu] = useState("홈");
  const [businessType, setBusinessType] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function loadSessionAndProfile() {
      const {
        data: { session },
        error: sessionError,
      } = await supabase.auth.getSession();

      if (!mounted) return;

      if (sessionError || !session) {
        router.replace("/login");
        return;
      }

      const { data: profile } = await supabase
        .from("business_profiles")
        .select("business_name,owner_name,business_type")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (!mounted) return;

      setBusinessName(profile?.business_name || "");
      setOwnerName(profile?.owner_name || "");
      setBusinessType(profile?.business_type || "");
      setAuthChecking(false);
    }

    void loadSessionAndProfile();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) router.replace("/login");
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [router]);

  function go(name: string) {
    setActiveMenu(name);
    setMoreOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  if (authChecking) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f5f6f8]">
        <div className="rounded-2xl border border-slate-200 bg-white px-6 py-5 text-sm font-bold text-slate-500 shadow-sm">
          로그인 상태를 확인하고 있습니다...
        </div>
      </main>
    );
  }

  const businessLabel =
    BUSINESS_TYPE_LABELS[businessType] || "업종 미설정";
  const displayName = ownerName || "사장님";
  const menus = getMenus(businessType);

  return (
    <main className="min-h-screen bg-[#f5f6f8] text-slate-900">
      <div className="flex min-h-screen min-w-0">
        {/* PC 사이드바 */}
        <aside className="hidden w-64 shrink-0 flex-col bg-slate-950 p-5 text-white md:flex">
          <button
            type="button"
            onClick={() => go("홈")}
            className="mb-8 text-left"
          >
            <div className="text-2xl font-black tracking-tight">
              견적<span className="text-blue-400">AI</span>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              사장님을 위한 AI 업무비서
            </p>
          </button>

          <nav className="space-y-1.5">
            {menus.map((menu) => (
              <button
                key={menu.name}
                type="button"
                onClick={() => go(menu.name)}
                className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm transition ${
                  activeMenu === menu.name
                    ? "bg-blue-600 font-bold text-white shadow-sm"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <span className="w-6 text-center text-base">{menu.icon}</span>
                <span>{menu.name}</span>
              </button>
            ))}
          </nav>

          <div className="mt-auto rounded-2xl bg-slate-900 p-4">
            <p className="text-xs text-slate-500">현재 업종</p>
            <p className="mt-1 font-bold text-white">{businessLabel}</p>
            <p className="mt-1 truncate text-xs text-slate-500">
              {businessName || "업체정보를 설정해주세요."}
            </p>
          </div>
        </aside>

        {/* 메인 */}
        <section className="min-w-0 flex-1 overflow-x-hidden">
          <header className="flex h-20 items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-6 lg:px-10">
            <div>
              <p className="text-xs font-bold tracking-wide text-blue-600">AI QUOTE ASSISTANT</p>
              <h1 className="mt-1 text-xl font-black">{activeMenu}</h1>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden text-right sm:block">
                <p className="text-sm font-bold">{displayName}</p>
                <p className="text-xs text-slate-400">{businessLabel}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-950 text-sm font-bold text-white">
                {displayName.slice(0, 1)}
              </div>
            </div>
          </header>

          <div className="p-5 pb-28 sm:p-7 lg:p-10 lg:pb-10">
            {activeMenu === "홈" && (
              <HomeMenu
                ownerName={displayName}
                businessName={businessName}
                businessLabel={businessLabel}
                menus={menus}
                onNavigate={go}
              />
            )}

            {activeMenu === "고객 관리" && <CustomerManager />}
            {activeMenu === "견적 관리" && <EstimateManager />}
            {activeMenu === "AI 상담" && <ConsultationManager />}
            {activeMenu === "계약 관리" && <ContractManager onNavigate={go} />}
            {activeMenu === "미수금 관리" && <UnpaidManager onNavigate={go} />}
            {activeMenu === "매출 관리" && <SalesManager onNavigate={go} />}
            {activeMenu === "단가 관리" && <PriceItemManager />}
            {activeMenu === "설정" && <SettingsManager />}
          </div>
        </section>
      </div>

      {/* 모바일 하단 메뉴 */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-slate-200 bg-white/95 px-2 pb-[env(safe-area-inset-bottom)] shadow-[0_-6px_24px_rgba(15,23,42,0.08)] backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-xl items-stretch justify-around">
          {menus.slice(0, 4).map((menu) => (
            <button
              key={menu.name}
              type="button"
              onClick={() => go(menu.name)}
              className={`flex min-w-0 flex-1 flex-col items-center gap-1 px-1 py-3 text-[11px] font-bold ${
                activeMenu === menu.name ? "text-blue-600" : "text-slate-400"
              }`}
            >
              <span className="text-lg leading-none">{menu.icon}</span>
              <span className="truncate">{menu.name}</span>
            </button>
          ))}
          <button
            type="button"
            onClick={() => setMoreOpen((value) => !value)}
            className={`flex min-w-0 flex-1 flex-col items-center gap-1 px-1 py-3 text-[11px] font-bold ${
              moreOpen ? "text-blue-600" : "text-slate-400"
            }`}
          >
            <span className="text-lg leading-none">☰</span>
            <span>더보기</span>
          </button>
        </div>
      </nav>

      {moreOpen && (
        <div className="fixed inset-x-3 bottom-24 z-50 rounded-3xl border border-slate-200 bg-white p-3 shadow-2xl md:hidden">
          <div className="grid grid-cols-2 gap-2">
            {menus.slice(4).map((menu) => (
              <button
                key={menu.name}
                type="button"
                onClick={() => go(menu.name)}
                className={`rounded-2xl p-4 text-left ${
                  activeMenu === menu.name ? "bg-blue-50 text-blue-700" : "bg-slate-50"
                }`}
              >
                <div className="text-xl">{menu.icon}</div>
                <p className="mt-2 text-sm font-black">{menu.name}</p>
                <p className="mt-1 text-[11px] leading-4 text-slate-400">{menu.description}</p>
              </button>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}

function HomeMenu({
  ownerName,
  businessName,
  businessLabel,
  menus,
  onNavigate,
}: {
  ownerName: string;
  businessName: string;
  businessLabel: string;
  menus: MenuItem[];
  onNavigate: (name: string) => void;
}) {
  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
        <p className="text-sm font-bold text-blue-600">견적AI</p>
        <h2 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
          안녕하세요, {ownerName} 👋
        </h2>
        <p className="mt-3 text-sm leading-6 text-slate-500 sm:text-base">
          {businessLabel} 업무에 필요한 기능만 빠르게 사용하세요.
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          <span className="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700">
            현재 업종 · {businessLabel}
          </span>
          {businessName && (
            <span className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-600">
              {businessName}
            </span>
          )}
        </div>
      </div>

      <div className="mb-6 rounded-2xl border border-sky-100 bg-sky-50 p-5">
        <p className="text-xs font-black tracking-wide text-sky-600">
          현재 적용 업종
        </p>
        <div className="mt-1 flex items-center justify-between gap-4">
          <p className="text-lg font-black text-slate-900">
            {businessLabel}
          </p>
          <p className="text-xs font-bold text-slate-500">
            견적·단가·AI 기능에 동일하게 적용됩니다.
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {menus.slice(1).map((menu) => (
          <button
            key={menu.name}
            type="button"
            onClick={() => onNavigate(menu.name)}
            className="group rounded-3xl border border-slate-200 bg-white p-6 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-md"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-50 text-2xl transition group-hover:bg-blue-50">
              {menu.icon}
            </div>
            <h3 className="mt-5 text-lg font-black">{menu.name}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">{menu.description}</p>
            <p className="mt-5 text-sm font-black text-blue-600">바로가기 →</p>
          </button>
        ))}
      </div>

      <div className="mt-8 rounded-3xl bg-slate-950 p-6 text-white sm:p-8">
        <p className="text-xs font-bold tracking-widest text-blue-400">ONE STOP WORKFLOW</p>
        <h3 className="mt-2 text-2xl font-black">
          {businessLabel} 문의부터 견적·계약까지 한곳에서
        </h3>
        <div className="mt-6 grid gap-3 sm:grid-cols-4">
          {[
            ["01", "고객 문의", "문의 내용을 빠르게 기록"],
            ["02", "AI 견적", "내 단가표로 견적 계산"],
            ["03", "계약", "진행 상태를 한눈에 관리"],
            ["04", "매출", "완료된 거래를 관리"],
          ].map(([number, title, text]) => (
            <div key={number} className="rounded-2xl bg-white/5 p-4">
              <p className="text-xs font-bold text-blue-300">{number}</p>
              <p className="mt-2 font-black">{title}</p>
              <p className="mt-1 text-xs leading-5 text-slate-400">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}