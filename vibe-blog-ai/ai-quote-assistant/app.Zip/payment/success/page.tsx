"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

function PaymentSuccessContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [message, setMessage] = useState(
    "결제를 확인하고 이용권을 적용하는 중입니다..."
  );

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const paymentKey = searchParams.get("paymentKey");
    const orderId = searchParams.get("orderId");
    const amount = searchParams.get("amount");

    if (!paymentKey || !orderId || !amount) {
      setMessage("결제 결과 정보가 없습니다.");
      setLoading(false);
      return;
    }

    let cancelled = false;

    async function confirmPayment() {
      try {
        const response = await fetch("/api/toss/confirm", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            paymentKey,
            orderId,
            amount: Number(amount),
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data?.message || "결제 승인에 실패했습니다."
          );
        }

        if (cancelled) return;

        setMessage(
          data.plan === "starter"
            ? "스타터 플랜 30회가 적용되었습니다."
            : "프로 플랜 100회가 적용되었습니다."
        );

        setLoading(false);

        setTimeout(() => {
          router.replace("/");
          router.refresh();
        }, 1800);
      } catch (error) {
        if (cancelled) return;

        setMessage(
          error instanceof Error
            ? error.message
            : "결제 승인 중 오류가 발생했습니다."
        );

        setLoading(false);
      }
    }

    void confirmPayment();

    return () => {
      cancelled = true;
    };
  }, [router, searchParams]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
      <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <div className="text-5xl">💳</div>

        <h1 className="mt-5 text-2xl font-black text-slate-950">
          {loading ? "결제 확인 중" : "결제 처리 결과"}
        </h1>

        <p className="mt-4 whitespace-pre-line text-sm font-bold leading-6 text-slate-500">
          {message}
        </p>

        {!loading && (
          <button
            type="button"
            onClick={() => router.replace("/")}
            className="mt-7 w-full rounded-xl bg-blue-600 px-5 py-4 text-sm font-black text-white"
          >
            견적AI로 돌아가기
          </button>
        )}
      </div>
    </main>
  );
}

function PaymentSuccessLoading() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
      <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <div className="text-5xl">💳</div>

        <h1 className="mt-5 text-2xl font-black text-slate-950">
          결제 확인 중
        </h1>

        <p className="mt-4 text-sm font-bold leading-6 text-slate-500">
          결제 결과를 확인하고 있습니다...
        </p>
      </div>
    </main>
  );
}

export default function PaymentSuccessPage() {
  return (
    <Suspense fallback={<PaymentSuccessLoading />}>
      <PaymentSuccessContent />
    </Suspense>
  );
}