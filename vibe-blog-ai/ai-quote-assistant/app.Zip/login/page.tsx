"use client";

import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

const BUSINESS_TYPES = [
  {
    value: "air_conditioner",
    label: "에어컨",
    icon: "❄️",
  },
  {
    value: "cleaning",
    label: "청소",
    icon: "🧹",
  },
  {
    value: "wallpaper_flooring",
    label: "도배·장판",
    icon: "🏠",
  },
  {
    value: "interior_film",
    label: "인테리어필름",
    icon: "✨",
  },
  {
    value: "moving",
    label: "이사",
    icon: "🚚",
  },
  {
    value: "demolition",
    label: "철거",
    icon: "🔨",
  },
  {
    value: "auto_repair",
    label: "자동차 정비",
    icon: "🚗",
  },
  {
    value: "sign_print",
    label: "간판·인쇄",
    icon: "🪧",
  },
  {
    value: "screen_sash",
    label: "방충망·샷시",
    icon: "🪟",
  },
  {
    value: "repair",
    label: "출장수리",
    icon: "🔧",
  },
  {
    value: "other",
    label: "기타",
    icon: "➕",
  },
];

function getBusinessLabel(value: string) {
  return (
    BUSINESS_TYPES.find((item) => item.value === value)?.label ||
    value
  );
}

export default function LoginPage() {
  const router = useRouter();

  const [mode, setMode] = useState<"login" | "signup">("login");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [businessName, setBusinessName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [phone, setPhone] = useState("");
  const [businessType, setBusinessType] = useState("");

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState<
    "info" | "success" | "error"
  >("info");

  useEffect(() => {
    let mounted = true;

    async function checkSession() {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();

        if (mounted && session) {
          router.replace("/");
          router.refresh();
        }
      } catch (error) {
        console.error("SESSION CHECK ERROR:", error);
      }
    }

    void checkSession();

    return () => {
      mounted = false;
    };
  }, [router]);

  function showMessage(
    text: string,
    type: "info" | "success" | "error" = "info"
  ) {
    setMessage(text);
    setMessageType(type);
  }

  async function saveBusinessProfile(
    userId: string,
    profileData: {
      businessName: string;
      ownerName: string;
      phone: string;
      businessType: string;
    }
  ) {
    const { error } = await supabase
      .from("business_profiles")
      .upsert(
        {
          user_id: userId,
          business_name: profileData.businessName,
          owner_name: profileData.ownerName,
          phone: profileData.phone,
          business_type: profileData.businessType,
          updated_at: new Date().toISOString(),
        },
        {
          onConflict: "user_id",
        }
      );

    if (error) {
      throw error;
    }
  }

  async function handleSignup() {
    if (!businessName.trim()) {
      showMessage("업체명을 입력해주세요.", "error");
      return;
    }

    if (!ownerName.trim()) {
      showMessage("대표자명을 입력해주세요.", "error");
      return;
    }

    if (!phone.trim()) {
      showMessage("연락처를 입력해주세요.", "error");
      return;
    }

    if (!businessType) {
      showMessage("업종을 선택해주세요.", "error");
      return;
    }

    const selectedBusinessType = getBusinessLabel(businessType);

    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: {
          business_name: businessName.trim(),
          owner_name: ownerName.trim(),
          phone: phone.trim(),
          business_type: businessType,
          business_type_label: selectedBusinessType,
        },
      },
    });

    if (error) {
      throw error;
    }

    if (!data.user) {
      throw new Error(
        "회원가입은 완료되었지만 사용자 정보를 확인할 수 없습니다."
      );
    }

    /*
     * 이메일 인증이 꺼져 있어 바로 세션이 만들어지는 경우
     * 여기서 business_profiles에 바로 저장합니다.
     */
    if (data.session) {
      await saveBusinessProfile(data.user.id, {
        businessName,
        ownerName,
        phone,
        businessType,
      });

      showMessage(
        "회원가입이 완료되었습니다. 바로 시작합니다.",
        "success"
      );

      setTimeout(() => {
        router.replace("/");
        router.refresh();
      }, 800);

      return;
    }

    /*
     * 이메일 인증이 켜져 있는 경우에는
     * 위에서 auth user metadata에 업체정보를 먼저 저장해뒀습니다.
     *
     * 인증 후 로그인하면 handleLogin()에서
     * business_profiles를 자동으로 생성합니다.
     */
    showMessage(
      "회원가입이 완료되었습니다. 이메일 인증 후 로그인해주세요.",
      "success"
    );

    setMode("login");
    setPassword("");
  }

  async function handleLogin() {
    const { data, error } =
      await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

    if (error) {
      throw error;
    }

    if (!data.session || !data.user) {
      throw new Error("로그인 세션을 만들지 못했습니다.");
    }

    /*
     * 로그인 후 business_profiles가 없는 경우
     * 회원가입 때 저장해둔 user_metadata를 이용해서
     * 업체 프로필을 자동 생성합니다.
     */
    const metadata = data.user.user_metadata || {};

    const metadataBusinessType =
      metadata.business_type || "";

    const metadataBusinessName =
      metadata.business_name || "";

    const metadataOwnerName =
      metadata.owner_name || "";

    const metadataPhone =
      metadata.phone || "";

    if (
      metadataBusinessType &&
      metadataBusinessName
    ) {
      try {
        await saveBusinessProfile(data.user.id, {
          businessName: metadataBusinessName,
          ownerName: metadataOwnerName,
          phone: metadataPhone,
          businessType: metadataBusinessType,
        });
      } catch (profileError) {
        console.error(
          "PROFILE SYNC ERROR:",
          profileError
        );

        /*
         * 프로필 저장 실패 때문에 로그인 자체를 막지는 않습니다.
         * 이미 로그인은 성공했으므로 홈으로 이동합니다.
         */
      }
    }

    router.replace("/");
    router.refresh();
  }

  async function handleSubmit(
    e: FormEvent<HTMLFormElement>
  ) {
    e.preventDefault();

    const cleanEmail = email.trim();

    setMessage("");

    if (!cleanEmail || !password) {
      showMessage(
        "이메일과 비밀번호를 입력해주세요.",
        "error"
      );
      return;
    }

    if (password.length < 6) {
      showMessage(
        "비밀번호는 6자 이상 입력해주세요.",
        "error"
      );
      return;
    }

    setLoading(true);

    try {
      if (mode === "signup") {
        await handleSignup();
      } else {
        await handleLogin();
      }
    } catch (error) {
      console.error("AUTH ERROR:", error);

      if (error instanceof Error) {
        if (
          error.message.includes(
            "Invalid login credentials"
          )
        ) {
          showMessage(
            "이메일 또는 비밀번호가 올바르지 않습니다.",
            "error"
          );
        } else if (
          error.message.includes("Email not confirmed")
        ) {
          showMessage(
            "이메일 인증을 먼저 완료해주세요.",
            "error"
          );
        } else if (
          error.message.includes(
            "duplicate key"
          )
        ) {
          showMessage(
            "이미 등록된 업체정보가 있습니다.",
            "error"
          );
        } else {
          showMessage(error.message, "error");
        }
      } else {
        showMessage(
          "로그인 처리 중 오류가 발생했습니다.",
          "error"
        );
      }
    } finally {
      setLoading(false);
    }
  }

  const messageClass =
    messageType === "error"
      ? "bg-red-50 text-red-600"
      : messageType === "success"
        ? "bg-emerald-50 text-emerald-700"
        : "bg-sky-50 text-sky-700";

  return (
    <main className="min-h-screen bg-sky-50 px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-6xl items-center justify-center">
        <div className="w-full">
          {/* 브랜드 */}
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-sky-500 text-3xl shadow-lg shadow-sky-200">
              🏠
            </div>

            <div className="text-3xl font-black tracking-tight text-slate-900">
              해결<span className="text-sky-500">소</span>
            </div>

            <p className="mt-2 text-sm font-semibold text-slate-500">
              필요한 일, 해결소에서
            </p>
          </div>

          <div
            className={
              mode === "signup"
                ? "mx-auto grid max-w-5xl gap-6 lg:grid-cols-[0.8fr_1.2fr]"
                : "mx-auto max-w-md"
            }
          >
            {/* 로그인 / 기본 계정 */}
            <div className="rounded-3xl border border-slate-200 bg-white p-7 shadow-xl shadow-sky-100 sm:p-9">
              <div className="mb-7 flex rounded-xl bg-sky-50 p-1">
                <button
                  type="button"
                  onClick={() => {
                    setMode("login");
                    setMessage("");
                  }}
                  className={`flex-1 rounded-lg py-3 text-sm font-black transition ${
                    mode === "login"
                      ? "bg-white text-sky-600 shadow-sm"
                      : "text-slate-400"
                  }`}
                >
                  로그인
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMode("signup");
                    setMessage("");
                  }}
                  className={`flex-1 rounded-lg py-3 text-sm font-black transition ${
                    mode === "signup"
                      ? "bg-white text-sky-600 shadow-sm"
                      : "text-slate-400"
                  }`}
                >
                  회원가입
                </button>
              </div>

              <div className="mb-7">
                <p className="text-sm font-black text-sky-500">
                  {mode === "login"
                    ? "WELCOME BACK"
                    : "CREATE ACCOUNT"}
                </p>

                <h1 className="mt-1 text-2xl font-black text-slate-900">
                  {mode === "login"
                    ? "다시 만나서 반가워요 👋"
                    : "사장님 계정을 만들어주세요"}
                </h1>

                <p className="mt-2 text-sm leading-6 text-slate-500">
                  {mode === "login"
                    ? "해결소에 로그인하면 고객·견적·계약 정보를 관리할 수 있습니다."
                    : "업체정보와 업종을 선택하면 해결소를 바로 시작할 수 있습니다."}
                </p>
              </div>

              <form
                onSubmit={handleSubmit}
                className="space-y-5"
              >
                <div>
                  <label className="mb-2 block text-sm font-bold text-slate-800">
                    이메일 *
                  </label>

                  <input
                    type="email"
                    value={email}
                    onChange={(e) =>
                      setEmail(e.target.value)
                    }
                    placeholder="example@email.com"
                    autoComplete="email"
                    className="w-full rounded-xl border border-slate-200 px-4 py-3.5 text-sm outline-none transition focus:border-sky-400 focus:ring-4 focus:ring-sky-100"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-slate-800">
                    비밀번호 *
                  </label>

                  <input
                    type="password"
                    value={password}
                    onChange={(e) =>
                      setPassword(e.target.value)
                    }
                    placeholder="6자 이상 입력"
                    autoComplete={
                      mode === "login"
                        ? "current-password"
                        : "new-password"
                    }
                    className="w-full rounded-xl border border-slate-200 px-4 py-3.5 text-sm outline-none transition focus:border-sky-400 focus:ring-4 focus:ring-sky-100"
                  />
                </div>

                {mode === "signup" && (
                  <>
                    <div>
                      <label className="mb-2 block text-sm font-bold text-slate-800">
                        업체명 *
                      </label>

                      <input
                        value={businessName}
                        onChange={(e) =>
                          setBusinessName(
                            e.target.value
                          )
                        }
                        placeholder="예) 바꾸다필름"
                        className="w-full rounded-xl border border-slate-200 px-4 py-3.5 text-sm outline-none transition focus:border-sky-400 focus:ring-4 focus:ring-sky-100"
                      />
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <label className="mb-2 block text-sm font-bold text-slate-800">
                          대표자명 *
                        </label>

                        <input
                          value={ownerName}
                          onChange={(e) =>
                            setOwnerName(
                              e.target.value
                            )
                          }
                          placeholder="대표자명"
                          className="w-full rounded-xl border border-slate-200 px-4 py-3.5 text-sm outline-none transition focus:border-sky-400 focus:ring-4 focus:ring-sky-100"
                        />
                      </div>

                      <div>
                        <label className="mb-2 block text-sm font-bold text-slate-800">
                          연락처 *
                        </label>

                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) =>
                            setPhone(e.target.value)
                          }
                          placeholder="010-0000-0000"
                          autoComplete="tel"
                          className="w-full rounded-xl border border-slate-200 px-4 py-3.5 text-sm outline-none transition focus:border-sky-400 focus:ring-4 focus:ring-sky-100"
                        />
                      </div>
                    </div>
                  </>
                )}

                {message && (
                  <div
                    className={`rounded-xl px-4 py-3 text-sm font-bold leading-6 ${messageClass}`}
                  >
                    {message}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-xl bg-sky-500 px-5 py-4 text-sm font-black text-white shadow-lg shadow-sky-200 transition hover:bg-sky-600 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {loading
                    ? "처리 중..."
                    : mode === "login"
                      ? "해결소 로그인"
                      : "다음 단계 →"}
                </button>
              </form>

              <p className="mt-6 text-center text-xs leading-5 text-slate-400">
                로그인한 계정별로
                <br />
                고객·상담·견적 데이터를 관리합니다.
              </p>
            </div>

            {/* 업종 선택 */}
            {mode === "signup" && (
              <div className="rounded-3xl border border-slate-200 bg-white p-7 shadow-xl shadow-sky-100 sm:p-9">
                <div className="mb-7">
                  <p className="text-sm font-black text-sky-500">
                    BUSINESS TYPE
                  </p>

                  <h2 className="mt-1 text-2xl font-black text-slate-900">
                    어떤 일을 하고 계신가요?
                  </h2>

                  <p className="mt-2 text-sm leading-6 text-slate-500">
                    선택한 업종을 기준으로 견적과 서비스를 구성합니다.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {BUSINESS_TYPES.map((type) => {
                    const selected =
                      businessType === type.value;

                    return (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => {
                          setBusinessType(
                            type.value
                          );
                          setMessage("");
                        }}
                        className={`relative rounded-2xl border p-4 text-left transition ${
                          selected
                            ? "border-sky-400 bg-sky-50 ring-2 ring-sky-200"
                            : "border-slate-200 bg-white hover:border-sky-300 hover:bg-sky-50/50"
                        }`}
                      >
                        {selected && (
                          <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-sky-500 text-xs font-black text-white">
                            ✓
                          </span>
                        )}

                        <div className="text-2xl">
                          {type.icon}
                        </div>

                        <div
                          className={`mt-3 text-sm font-black ${
                            selected
                              ? "text-sky-600"
                              : "text-slate-900"
                          }`}
                        >
                          {type.label}
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-6 rounded-2xl bg-sky-50 p-5">
                  {businessType ? (
                    <>
                      <p className="text-xs font-bold text-sky-500">
                        선택한 업종
                      </p>

                      <p className="mt-1 text-lg font-black text-slate-900">
                        {
                          BUSINESS_TYPES.find(
                            (item) =>
                              item.value ===
                              businessType
                          )?.icon
                        }{" "}
                        {
                          BUSINESS_TYPES.find(
                            (item) =>
                              item.value ===
                              businessType
                          )?.label
                        }
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-sm font-black text-slate-800">
                        업종을 선택해주세요.
                      </p>

                      <p className="mt-1 text-xs leading-5 text-slate-500">
                        선택한 업종은 사장님 계정에 저장됩니다.
                      </p>
                    </>
                  )}

                  <p className="mt-3 text-xs leading-5 text-slate-500">
                    단가표는 자동으로 만들지 않습니다.
                    <br />
                    가입 후 사장님이 직접 필요한 단가를 등록합니다.
                  </p>
                </div>

                <div className="mt-6 rounded-2xl border border-slate-100 bg-slate-50 p-5">
                  <p className="text-sm font-black text-slate-900">
                    해결소는 업종별로 다르게 작동합니다.
                  </p>

                  <p className="mt-2 text-xs leading-5 text-slate-500">
                    예를 들어 에어컨 업체는 에어컨 단가를,
                    필름 업체는 필름 단가를 사용합니다.
                    다른 업종의 단가가 섞이지 않도록 관리합니다.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}