"use client";

import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type MatchRequest = {
  id: string;
  customer_user_id: string | null;
  customer_name: string;
  customer_phone: string | null;
  region: string | null;
  service_type: string | null;
  inquiry: string | null;
  status: string;
  matched_business_id: string | null;
  matched_customer_id: string | null;
  accepted_at: string | null;
  created_at: string;
};

type BusinessProfile = {
  business_type: string | null;
  business_name: string | null;
};

export default function MatchRequestManager() {
  const [requests, setRequests] = useState<MatchRequest[]>([]);
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [acceptingId, setAcceptingId] = useState<string | null>(null);
  const [error, setError] = useState("");

  const loadRequests = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      const { data: profileData, error: profileError } = await supabase
        .from("business_profiles")
        .select("business_type,business_name")
        .eq("user_id", user.id)
        .maybeSingle();

      if (profileError) throw profileError;
      if (!profileData?.business_type) {
        throw new Error("설정에서 업체 업종을 먼저 선택하고 저장해주세요.");
      }

      setBusinessProfile(profileData as BusinessProfile);

      const { data: requestData, error: requestError } = await supabase
        .from("match_requests")
        .select("id,customer_user_id,customer_name,customer_phone,region,service_type,inquiry,status,matched_business_id,matched_customer_id,accepted_at,created_at")
        .eq("status", "문의접수")
        .order("created_at", { ascending: false });

      if (requestError) throw requestError;
      setRequests((requestData ?? []) as MatchRequest[]);
    } catch (err) {
      console.error("MATCH REQUEST LOAD ERROR:", err);
      setError(err instanceof Error ? err.message : "매칭 문의를 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadRequests();
  }, [loadRequests]);

  async function acceptRequest(request: MatchRequest) {
    if (!request.customer_user_id) {
      setError("이 문의는 고객 계정 연결 정보가 없습니다. 새로 등록한 문의로 테스트해주세요.");
      return;
    }

    const confirmed = window.confirm(`${request.customer_name} 고객의 문의를 수락하시겠습니까?`);
    if (!confirmed) return;

    setAcceptingId(request.id);
    setError("");

    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      // 먼저 문의를 선점합니다.
      const { data: claimedRequest, error: claimError } = await supabase
        .from("match_requests")
        .update({
          matched_business_id: user.id,
          status: "업체수락",
          accepted_at: new Date().toISOString(),
        })
        .eq("id", request.id)
        .eq("status", "문의접수")
        .select("id")
        .maybeSingle();

      if (claimError) throw claimError;
      if (!claimedRequest) {
        throw new Error("다른 업체가 먼저 수락했거나 이미 처리된 문의입니다.");
      }

      // 업체 업무용 고객 행을 만들고, 원래 고객 계정과 연결합니다.
      const { data: insertedCustomer, error: customerInsertError } = await supabase
        .from("customers")
        .insert({
          user_id: user.id,
          name: request.customer_name,
          phone: request.customer_phone,
          region: request.region,
          service_type: request.service_type,
          inquiry: request.inquiry,
          status: "신규문의",
        })
        .select("id")
        .single();

      if (customerInsertError) throw customerInsertError;

      const { error: linkError } = await supabase
        .from("match_requests")
        .update({ matched_customer_id: insertedCustomer.id })
        .eq("id", request.id)
        .eq("matched_business_id", user.id);

      if (linkError) throw linkError;

      setRequests((current) => current.filter((item) => item.id !== request.id));
      alert(`${request.customer_name} 고객의 문의를 수락했습니다.\n고객 관리에서 확인할 수 있습니다.`);
    } catch (err) {
      console.error("MATCH REQUEST ACCEPT ERROR:", err);
      setError(err instanceof Error ? err.message : "문의 수락 중 오류가 발생했습니다.");
    } finally {
      setAcceptingId(null);
    }
  }

  function formatDate(value: string) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "-";
    return date.toLocaleString("ko-KR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  return (
    <div className="pb-28">
      <div className="mb-7">
        <p className="text-sm font-bold text-emerald-600">MATCHING REQUESTS</p>
        <h2 className="mt-1 text-3xl font-black">매칭 문의</h2>
        <p className="mt-2 text-sm leading-6 text-slate-500">
          내 업종을 찾는 고객 문의를 확인하고 수락할 수 있습니다.
        </p>
      </div>

      {businessProfile && (
        <div className="mb-5 rounded-2xl border border-blue-100 bg-blue-50 p-4">
          <p className="text-xs font-bold text-blue-500">현재 업체</p>
          <p className="mt-1 font-black text-blue-900">
            {businessProfile.business_name || "업체명 미설정"}
          </p>
        </div>
      )}

      {error && (
        <div className="mb-5 rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold leading-6 text-red-600">
          {error}
        </div>
      )}

      <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-bold text-slate-400">NEW REQUESTS</p>
            <h3 className="mt-1 text-xl font-black">신규 고객 문의</h3>
          </div>
          <div className="rounded-xl bg-emerald-50 px-4 py-2 text-sm font-black text-emerald-700">
            {requests.length}건
          </div>
        </div>

        {loading ? (
          <div className="py-14 text-center text-sm font-bold text-slate-400">
            매칭 문의를 불러오는 중...
          </div>
        ) : requests.length === 0 ? (
          <div className="mt-6 rounded-2xl bg-slate-50 px-5 py-14 text-center">
            <p className="text-3xl">📭</p>
            <p className="mt-3 font-black text-slate-700">현재 신규 매칭 문의가 없습니다.</p>
            <p className="mt-2 text-sm text-slate-400">고객 문의가 등록되면 이곳에 표시됩니다.</p>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            {requests.map((request) => (
              <div key={request.id} className="rounded-2xl border border-slate-200 p-5">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-lg font-black">{request.service_type || "서비스 문의"}</p>
                      <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-blue-700">
                        {request.status}
                      </span>
                    </div>
                    <p className="mt-2 text-sm font-bold text-slate-500">📍 {request.region || "지역 미등록"}</p>
                    <p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-slate-700">
                      {request.inquiry || "문의 내용 없음"}
                    </p>
                    <p className="mt-4 text-xs text-slate-400">접수 {formatDate(request.created_at)}</p>
                  </div>

                  <button
                    type="button"
                    disabled={acceptingId === request.id || !request.customer_user_id}
                    onClick={() => void acceptRequest(request)}
                    className="shrink-0 rounded-xl bg-emerald-600 px-5 py-3 text-sm font-black text-white hover:bg-emerald-700 disabled:bg-slate-300"
                  >
                    {acceptingId === request.id
                      ? "수락 중..."
                      : request.customer_user_id
                        ? "🤝 문의 수락"
                        : "연결정보 없음"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}