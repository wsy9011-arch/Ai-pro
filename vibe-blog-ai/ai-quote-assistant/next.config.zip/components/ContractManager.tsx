"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Contract = {
  id: string;
  user_id: string;
  customer_id: string;
  estimate_id: string | null;
  contract_date: string;
  amount: number;
  status: string;
  memo: string | null;
  created_at: string;
  updated_at: string;
};

type Customer = {
  id: string;
  name: string;
  phone: string | null;
  region: string | null;
};

const STATUS_OPTIONS = ["전체", "계약대기", "계약진행", "계약완료", "계약취소"];

export default function ContractManager({
  onNavigate,
}: {
  onNavigate?: (menu: string) => void;
}) {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [statusFilter, setStatusFilter] = useState("전체");
  const [search, setSearch] = useState("");
  const [editingContract, setEditingContract] =
    useState<Contract | null>(null);
  const [selectedContractId, setSelectedContractId] =
    useState<string | null>(null);
  const [summaryModal, setSummaryModal] = useState<
    "전체" | "계약완료" | "계약대기" | null
  >(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      const { data: contractData, error: contractError } =
        await supabase
          .from("contracts")
          .select(
            "id,user_id,customer_id,estimate_id,contract_date,amount,status,memo,created_at,updated_at"
          )
          .eq("user_id", user.id)
          .order("contract_date", { ascending: false })
          .order("created_at", { ascending: false });

      if (contractError) throw contractError;

      const { data: customerData, error: customerError } =
        await supabase
          .from("customers")
          .select("id,name,phone,region")
          .eq("user_id", user.id);

      if (customerError) throw customerError;

      setContracts((contractData ?? []) as Contract[]);
      setCustomers((customerData ?? []) as Customer[]);
    } catch (err) {
      console.error("CONTRACT LOAD ERROR:", err);

      setError(
        err instanceof Error
          ? err.message
          : "계약 정보를 불러오지 못했습니다."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const filteredContracts = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    return contracts.filter((contract) => {
      const customer = customers.find(
        (item) => item.id === contract.customer_id
      );

      const matchesStatus =
        statusFilter === "전체" ||
        contract.status === statusFilter;

      const matchesSearch =
        !keyword ||
        customer?.name.toLowerCase().includes(keyword) ||
        customer?.phone?.toLowerCase().includes(keyword) ||
        customer?.region?.toLowerCase().includes(keyword) ||
        contract.memo?.toLowerCase().includes(keyword);

      return matchesStatus && matchesSearch;
    });
  }, [contracts, customers, statusFilter, search]);

  const completedContracts = useMemo(
    () =>
      contracts.filter(
        (contract) => contract.status === "계약완료"
      ),
    [contracts]
  );

  const waitingContracts = useMemo(
    () =>
      contracts.filter(
        (contract) => contract.status === "계약대기"
      ),
    [contracts]
  );

  const completedAmount = useMemo(
    () =>
      completedContracts.reduce(
        (sum, contract) => sum + Number(contract.amount || 0),
        0
      ),
    [completedContracts]
  );

  const totalAmount = useMemo(
    () =>
      contracts.reduce(
        (sum, contract) => sum + Number(contract.amount || 0),
        0
      ),
    [contracts]
  );

  function formatPrice(amount: number) {
    return `${Number(amount || 0).toLocaleString("ko-KR")}원`;
  }

  function formatContractNumber(id: string) {
    return `CT-${id.replace(/-/g, "").slice(0, 10).toUpperCase()}`;
  }

  function getCustomer(customerId: string) {
    return customers.find(
      (customer) => customer.id === customerId
    );
  }

  async function updateContract(
    id: string,
    updates: {
      status: string;
      contract_date: string;
      amount: number;
      memo: string | null;
    }
  ) {
    try {
      setError("");

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      const contract = contracts.find(
        (item) => item.id === id
      );

      if (!contract) {
        throw new Error("계약 정보를 찾을 수 없습니다.");
      }

      const { error: updateError } = await supabase
        .from("contracts")
        .update({
          status: updates.status,
          contract_date: updates.contract_date,
          amount: Number(updates.amount || 0),
          memo: updates.memo,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .eq("user_id", user.id);

      if (updateError) throw updateError;

      const customerStatus =
        updates.status === "계약완료"
          ? "계약완료"
          : updates.status === "계약취소"
          ? "계약대기"
          : "계약대기";

      const { error: customerError } = await supabase
        .from("customers")
        .update({
          status: customerStatus,
        })
        .eq("id", contract.customer_id)
        .eq("user_id", user.id);

      if (customerError) throw customerError;

      setEditingContract(null);
      await loadData();
    } catch (err) {
      console.error("CONTRACT UPDATE ERROR:", err);

      setError(
        err instanceof Error
          ? err.message
          : "계약 수정 중 오류가 발생했습니다."
      );
    }
  }

  async function deleteContract(contract: Contract) {
    const customer = getCustomer(contract.customer_id);

    const confirmed = window.confirm(
      `${customer?.name || "해당 고객"}의 계약을 삭제하시겠습니까?\n\n계약금액: ${formatPrice(
        contract.amount
      )}\n\n삭제하면 매출에서도 제외됩니다.`
    );

    if (!confirmed) return;

    try {
      setError("");

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      const { error: deleteError } = await supabase
        .from("contracts")
        .delete()
        .eq("id", contract.id)
        .eq("user_id", user.id);

      if (deleteError) throw deleteError;

      const { error: customerError } = await supabase
        .from("customers")
        .update({
          status: "계약대기",
        })
        .eq("id", contract.customer_id)
        .eq("user_id", user.id);

      if (customerError) throw customerError;

      await loadData();
    } catch (err) {
      console.error("CONTRACT DELETE ERROR:", err);

      setError(
        err instanceof Error
          ? err.message
          : "계약 삭제 중 오류가 발생했습니다."
      );
    }
  }

  return (
    <div className="pb-28">
      <div className="mb-7">
        <p className="text-sm font-bold text-blue-600">
          CONTRACT MANAGEMENT
        </p>

        <h2 className="mt-1 text-3xl font-black">
          계약 관리
        </h2>

        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <p className="mt-2 text-sm text-slate-500">
            실제 등록된 계약을 관리하고 계약 금액을 확인합니다.
          </p>
          <button
            type="button"
            onClick={() => onNavigate?.("미수금 관리")}
            className="shrink-0 rounded-xl bg-red-600 px-4 py-3 text-sm font-black text-white hover:bg-red-700"
          >
            💳 미수금 관리 →
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-5 rounded-xl bg-red-50 px-4 py-3 text-sm font-bold text-red-600">
          {error}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryCard
          title="전체 계약"
          value={`${contracts.length}건`}
          description="등록된 계약"
          icon="🤝"
          onClick={() => setSummaryModal("전체")}
        />

        <SummaryCard
          title="계약 완료"
          value={`${completedContracts.length}건`}
          description="실제 계약 완료"
          icon="✅"
          onClick={() => setSummaryModal("계약완료")}
        />

        <SummaryCard
          title="계약 완료 금액"
          value={formatPrice(completedAmount)}
          description="실제 매출 반영 금액"
          icon="💰"
          onClick={() => setSummaryModal("계약완료")}
        />

        <SummaryCard
          title="계약 대기"
          value={`${waitingContracts.length}건`}
          description="확정 전 계약"
          icon="⏳"
          onClick={() => setSummaryModal("계약대기")}
        />
      </div>

      <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm font-bold text-slate-400">
              CONTRACT LIST
            </p>

            <h3 className="mt-1 text-xl font-black">
              계약 목록
            </h3>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <input
              value={search}
              onChange={(event) =>
                setSearch(event.target.value)
              }
              placeholder="고객명·전화번호·지역 검색"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:bg-white sm:w-64"
            />

            <select
              value={statusFilter}
              onChange={(event) =>
                setStatusFilter(event.target.value)
              }
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold outline-none"
            >
              {STATUS_OPTIONS.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-5 rounded-2xl bg-slate-50 p-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm font-bold text-slate-500">
              현재 조회 금액
            </p>

            <p className="text-xl font-black text-blue-600">
              {formatPrice(
                filteredContracts.reduce(
                  (sum, contract) =>
                    sum + Number(contract.amount || 0),
                  0
                )
              )}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="py-16 text-center text-sm text-slate-400">
            계약 정보를 불러오는 중...
          </div>
        ) : filteredContracts.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-sm font-bold text-slate-500">
              조건에 맞는 계약이 없습니다.
            </p>

            <p className="mt-1 text-xs text-slate-400">
              견적관리에서 승인된 견적을 계약으로 등록하면
              이곳에 표시됩니다.
            </p>
          </div>
        ) : (
          <div className="mt-5 space-y-3">
            {filteredContracts.map((contract) => {
              const customer = getCustomer(
                contract.customer_id
              );

              return (
                <div
                  key={contract.id}
                  className="rounded-2xl border border-slate-200 p-4 transition hover:border-blue-200 hover:bg-blue-50/20"
                >
                  <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-lg font-black">
                          {customer?.name || "고객 정보 없음"}
                        </p>

                        <StatusBadge
                          status={contract.status}
                        />
                      </div>

                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400">
                        {customer?.phone && (
                          <span>
                            📞 {customer.phone}
                          </span>
                        )}

                        {customer?.region && (
                          <span>
                            📍 {customer.region}
                          </span>
                        )}

                        <span>
                          📅 {contract.contract_date}
                        </span>

                        <span className="font-bold text-blue-600">
                          📄 계약번호 {formatContractNumber(contract.id)}
                        </span>
                      </div>

                      {contract.memo && (
                        <div className="mt-3 rounded-xl bg-slate-50 p-3">
                          <p className="text-xs font-bold text-slate-400">
                            메모
                          </p>

                          <p className="mt-1 whitespace-pre-wrap text-sm leading-6 text-slate-600">
                            {contract.memo}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center xl:justify-end">
                      <div className="rounded-2xl bg-blue-50 px-5 py-3 text-right">
                        <p className="text-xs font-bold text-slate-400">
                          계약금액
                        </p>

                        <p className="mt-1 text-xl font-black text-blue-700">
                          {formatPrice(
                            Number(contract.amount || 0)
                          )}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setSelectedContractId(
                            selectedContractId === contract.id
                              ? null
                              : contract.id
                          )
                        }
                        className="rounded-xl bg-blue-50 px-4 py-3 text-sm font-black text-blue-700 hover:bg-blue-100"
                      >
                        {selectedContractId === contract.id ? "상세 닫기" : "상세 보기"}
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          setEditingContract(contract)
                        }
                        className="rounded-xl bg-slate-100 px-4 py-3 text-sm font-black text-slate-700 hover:bg-slate-200"
                      >
                        수정
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          void deleteContract(contract)
                        }
                        className="rounded-xl bg-red-50 px-4 py-3 text-sm font-black text-red-600 hover:bg-red-100"
                      >
                        삭제
                      </button>
                    </div>
                  </div>

                  {selectedContractId === contract.id && (
                    <div className="mt-4 border-t border-slate-100 bg-slate-50 p-4">
                      <div className="grid gap-3 sm:grid-cols-4">
                        <DetailCard
                          label="계약번호"
                          value={formatContractNumber(contract.id)}
                        />
                        <DetailCard
                          label="계약금액"
                          value={formatPrice(contract.amount)}
                        />
                        <DetailCard
                          label="계약 상태"
                          value={contract.status || "계약대기"}
                        />
                        <DetailCard
                          label="입금 관리"
                          value="미수금 관리에서 확인"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => onNavigate?.("미수금 관리")}
                        className="mt-4 w-full rounded-xl bg-slate-900 px-4 py-3 text-sm font-black text-white hover:bg-slate-800"
                      >
                        💳 계약금·중도금·잔금 입금 관리 →
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-6 rounded-3xl bg-slate-950 p-5 text-white shadow-sm sm:p-6">
        <p className="text-sm font-bold text-blue-400">
          CONTRACT SUMMARY
        </p>

        <h3 className="mt-1 text-xl font-black">
          계약 현황 요약
        </h3>

        <div className="mt-7 space-y-5">
          <SummaryRow
            label="전체 계약"
            value={`${contracts.length}건`}
          />

          <SummaryRow
            label="전체 계약금액"
            value={formatPrice(totalAmount)}
          />

          <SummaryRow
            label="계약 완료"
            value={`${completedContracts.length}건`}
          />

          <SummaryRow
            label="실제 매출"
            value={formatPrice(completedAmount)}
          />

          <SummaryRow
            label="계약 대기"
            value={`${waitingContracts.length}건`}
          />
        </div>

        <div className="mt-7 rounded-2xl bg-white/10 p-4">
          <p className="text-xs leading-6 text-slate-400">
            계약관리에서 수정한 계약금액과 계약상태는
            매출분석에도 자동으로 반영됩니다.
          </p>
        </div>
      </div>

      {summaryModal && (
        <SummaryContractsModal
          title={
            summaryModal === "전체"
              ? "전체 계약"
              : summaryModal === "계약완료"
              ? "계약 완료"
              : "계약 대기"
          }
          contracts={
            summaryModal === "전체"
              ? contracts
              : summaryModal === "계약완료"
              ? completedContracts
              : waitingContracts
          }
          customers={customers}
          formatPrice={formatPrice}
          formatContractNumber={formatContractNumber}
          onClose={() => setSummaryModal(null)}
          onNavigate={onNavigate}
        />
      )}

      {editingContract && (
        <ContractEditModal
          contract={editingContract}
          onClose={() => setEditingContract(null)}
          onSave={updateContract}
          formatPrice={formatPrice}
        />
      )}
    </div>
  );
}

function DetailCard({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl bg-white p-4">
      <p className="text-xs font-bold text-slate-400">{label}</p>
      <p className="mt-2 font-black">{value}</p>
    </div>
  );
}

function SummaryCard({
  title,
  value,
  description,
  icon,
  onClick,
}: {
  title: string;
  value: string;
  description: string;
  icon: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full rounded-3xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500/30 sm:p-6"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-bold text-slate-400">{title}</p>
        <span className="text-xl">{icon}</span>
      </div>

      <p className="mt-4 break-words text-2xl font-black">{value}</p>

      <p className="mt-2 text-xs text-slate-400">{description}</p>

      <p className="mt-3 text-xs font-black text-blue-600">
        클릭해서 상세 보기 →
      </p>
    </button>
  );
}

function SummaryContractsModal({
  title,
  contracts,
  customers,
  formatPrice,
  formatContractNumber,
  onClose,
  onNavigate,
}: {
  title: string;
  contracts: Contract[];
  customers: Customer[];
  formatPrice: (amount: number) => string;
  formatContractNumber: (id: string) => string;
  onClose: () => void;
  onNavigate?: (menu: string) => void;
}) {
  return (
    <div className="fixed inset-0 z-[999998] flex items-center justify-center bg-black/60 p-4">
      <div className="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-100 p-5 sm:p-6">
          <div>
            <p className="text-sm font-bold text-blue-600">
              CONTRACT SUMMARY
            </p>
            <h3 className="mt-1 text-2xl font-black">{title}</h3>
            <p className="mt-1 text-sm text-slate-400">
              {contracts.length}건의 계약이 있습니다.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-100 font-bold text-slate-700 hover:bg-slate-200"
          >
            ✕
          </button>
        </div>

        <div className="overflow-y-auto p-5 sm:p-6">
          {contracts.length === 0 ? (
            <div className="rounded-2xl bg-slate-50 p-10 text-center">
              <p className="font-black">해당 계약이 없습니다.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {contracts.map((contract) => {
                const customer = customers.find(
                  (item) => item.id === contract.customer_id
                );

                return (
                  <div
                    key={contract.id}
                    className="rounded-2xl border border-slate-200 p-4"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="font-black">
                          {customer?.name || "고객 정보 없음"}
                        </p>
                        <p className="mt-1 text-xs text-slate-400">
                          {customer?.phone || "-"} ·{" "}
                          {customer?.region || "-"}
                        </p>
                        <p className="mt-1 text-xs text-slate-400">
                          계약일 {contract.contract_date}
                        </p>
                        <p className="mt-1 text-xs font-bold text-blue-600">
                          계약번호 {formatContractNumber(contract.id)}
                        </p>
                      </div>

                      <div className="text-left sm:text-right">
                        <p className="text-xs font-bold text-slate-400">
                          계약금액
                        </p>
                        <p className="mt-1 text-lg font-black text-blue-700">
                          {formatPrice(Number(contract.amount || 0))}
                        </p>
                        <span className="mt-1 inline-block rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">
                          {contract.status}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onNavigate?.("미수금 관리");
                        }}
                        className="rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-black text-white hover:bg-slate-800"
                      >
                        💳 미수금 관리 →
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="border-t border-slate-100 p-4 sm:p-5">
          <button
            type="button"
            onClick={onClose}
            className="w-full rounded-xl bg-slate-100 px-4 py-3 text-sm font-black text-slate-700 hover:bg-slate-200"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({
  status,
}: {
  status: string;
}) {
  const isCompleted = status === "계약완료";
  const isCancelled = status === "계약취소";

  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-bold ${
        isCompleted
          ? "bg-green-50 text-green-700"
          : isCancelled
          ? "bg-red-50 text-red-700"
          : "bg-amber-50 text-amber-700"
      }`}
    >
      {status}
    </span>
  );
}

function SummaryRow({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
      <span className="text-sm text-slate-400">
        {label}
      </span>

      <span className="text-right font-black">
        {value}
      </span>
    </div>
  );
}

function ContractEditModal({
  contract,
  onClose,
  onSave,
}: {
  contract: Contract;
  onClose: () => void;
  onSave: (
    id: string,
    updates: {
      status: string;
      contract_date: string;
      amount: number;
      memo: string | null;
    }
  ) => Promise<void>;
  formatPrice: (amount: number) => string;
}) {
  const [status, setStatus] = useState(
    contract.status
  );

  const [contractDate, setContractDate] = useState(
    contract.contract_date
  );

  const [amount, setAmount] = useState(
    String(contract.amount || 0)
  );

  const [memo, setMemo] = useState(
    contract.memo || ""
  );

  const [saving, setSaving] = useState(false);

  async function handleSave() {
    const numericAmount = Number(
      amount.replace(/,/g, "")
    );

    if (!contractDate) {
      window.alert("계약일을 입력해주세요.");
      return;
    }

    if (
      !Number.isFinite(numericAmount) ||
      numericAmount < 0
    ) {
      window.alert("계약금액을 올바르게 입력해주세요.");
      return;
    }

    setSaving(true);

    try {
      await onSave(contract.id, {
        status,
        contract_date: contractDate,
        amount: numericAmount,
        memo: memo.trim() || null,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[999999] flex items-end justify-center bg-black/60 sm:items-center sm:p-4">
      <div className="w-full max-w-lg rounded-t-3xl bg-white p-5 shadow-2xl sm:rounded-3xl sm:p-7">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-bold text-blue-600">
              CONTRACT EDIT
            </p>

            <h3 className="mt-1 text-2xl font-black">
              계약 수정
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 font-bold"
          >
            ✕
          </button>
        </div>

        <div className="mt-6 space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-400">
              계약 상태
            </label>

            <select
              value={status}
              onChange={(event) =>
                setStatus(event.target.value)
              }
              className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold outline-none focus:border-blue-500"
            >
              <option value="계약대기">
                계약대기
              </option>

              <option value="계약진행">
                계약진행
              </option>

              <option value="계약완료">
                계약완료
              </option>

              <option value="계약취소">
                계약취소
              </option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-400">
              계약일
            </label>

            <input
              type="date"
              value={contractDate}
              onChange={(event) =>
                setContractDate(event.target.value)
              }
              className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-400">
              계약금액
            </label>

            <input
              inputMode="numeric"
              value={amount}
              onChange={(event) =>
                setAmount(event.target.value)
              }
              className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-500"
              placeholder="0"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-400">
              메모
            </label>

            <textarea
              value={memo}
              onChange={(event) =>
                setMemo(event.target.value)
              }
              rows={4}
              placeholder="계약 관련 메모를 입력하세요."
              className="mt-2 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm leading-6 outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="mt-6 flex gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            className="flex-1 rounded-xl bg-slate-100 px-4 py-3 text-sm font-black text-slate-700"
          >
            취소
          </button>

          <button
            type="button"
            onClick={() => void handleSave()}
            disabled={saving}
            className="flex-[2] rounded-xl bg-blue-600 px-4 py-3 text-sm font-black text-white disabled:opacity-50"
          >
            {saving ? "저장 중..." : "계약 수정 저장"}
          </button>
        </div>
      </div>
    </div>
  );
}