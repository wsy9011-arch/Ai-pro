"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Contract = {
  id: string;
  user_id: string;
  customer_id: string;
  contract_date: string;
  amount: number;
  status: string;
  memo: string | null;
};

type Customer = {
  id: string;
  name: string;
  phone: string | null;
  region: string | null;
  service_type: string | null;
  status: string | null;
};

export default function InstallationManager() {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [view, setView] = useState<"all" | "progress" | "done">("all");

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      const [contractResult, customerResult] = await Promise.all([
        supabase
          .from("contracts")
          .select(
            "id,user_id,customer_id,contract_date,amount,status,memo"
          )
          .eq("user_id", user.id)
          .in("status", ["계약완료", "시공진행", "시공완료"])
          .order("contract_date", { ascending: false }),

        supabase
          .from("customers")
          .select(
            "id,name,phone,region,service_type,status"
          )
          .eq("user_id", user.id),
      ]);

      if (contractResult.error) throw contractResult.error;
      if (customerResult.error) throw customerResult.error;

      setContracts((contractResult.data ?? []) as Contract[]);
      setCustomers((customerResult.data ?? []) as Customer[]);
    } catch (err) {
      console.error("INSTALLATION LOAD ERROR:", err);
      setError(
        err instanceof Error
          ? err.message
          : "시공 정보를 불러오지 못했습니다."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const customerMap = useMemo(
    () => new Map(customers.map((customer) => [customer.id, customer])),
    [customers]
  );

  const installationItems = useMemo(() => {
    return contracts
      .map((contract) => ({
        contract,
        customer: customerMap.get(contract.customer_id),
      }))
      .filter((item) => {
        if (!item.customer) return false;

        if (view === "progress") {
          return item.contract.status === "시공진행";
        }

        if (view === "done") {
          return item.contract.status === "시공완료";
        }

        return ["계약완료", "시공진행", "시공완료"].includes(
          item.contract.status
        );
      });
  }, [contracts, customerMap, view]);

  const progressCount = useMemo(
    () => contracts.filter((contract) => contract.status === "시공진행").length,
    [contracts]
  );

  const doneCount = useMemo(
    () => contracts.filter((contract) => contract.status === "시공완료").length,
    [contracts]
  );

  async function updateContractStatus(
    contractId: string,
    status: "시공진행" | "시공완료"
  ) {
    setSavingId(contractId);
    setError("");

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) throw userError;
      if (!user) throw new Error("로그인이 필요합니다.");

      const { data: updatedContract, error: updateError } = await supabase
        .from("contracts")
        .update({ status })
        .eq("id", contractId)
        .eq("user_id", user.id)
        .select("id,user_id,customer_id,contract_date,amount,status,memo")
        .single();

      if (updateError) throw updateError;
      if (!updatedContract) throw new Error("시공 상태 변경 결과를 확인할 수 없습니다.");

      setContracts((current) =>
        current.map((contract) =>
          contract.id === contractId
            ? (updatedContract as Contract)
            : contract
        )
      );

      alert(
        status === "시공진행"
          ? "해당 계약만 시공 진행으로 변경되었습니다."
          : "해당 계약만 시공 완료로 변경되었습니다."
      );
    } catch (err) {
      console.error("INSTALLATION CONTRACT STATUS UPDATE ERROR:", err);
      setError(
        err instanceof Error
          ? err.message
          : "시공 상태 변경 중 오류가 발생했습니다."
      );
    } finally {
      setSavingId(null);
    }
  }

  function formatPrice(amount: number) {
    return `${Number(amount || 0).toLocaleString("ko-KR")}원`;
  }

  function formatDate(value: string) {
    if (!value) return "-";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleDateString("ko-KR");
  }

  return (
    <div className="pb-28">
      <div className="mb-7">
        <p className="text-sm font-bold text-blue-600">
          INSTALLATION MANAGEMENT
        </p>

        <h2 className="mt-1 text-3xl font-black">시공 관리</h2>

        <p className="mt-2 text-sm text-slate-500">
          계약 완료 고객의 시공 진행과 완료 상태를 관리합니다.
        </p>
      </div>

      {error && (
        <div className="mb-5 rounded-xl bg-red-50 px-4 py-3 text-sm font-bold text-red-600">
          {error}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-3">
        <SummaryCard
          title="시공 대상"
          value={`${installationItems.length}건`}
          description="계약 완료 고객"
          icon="🏠"
          active={view === "all"}
          onClick={() => setView("all")}
        />

        <SummaryCard
          title="시공 진행"
          value={`${progressCount}건`}
          description="현재 시공중"
          icon="🔨"
          active={view === "progress"}
          onClick={() => setView("progress")}
        />

        <SummaryCard
          title="시공 완료"
          value={`${doneCount}건`}
          description="완료된 시공"
          icon="✅"
          active={view === "done"}
          onClick={() => setView("done")}
        />
      </div>

      <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm font-bold text-slate-400">
              INSTALLATION LIST
            </p>
            <h3 className="mt-1 text-xl font-black">시공 목록</h3>
          </div>

          <button
            type="button"
            onClick={() => void loadData()}
            className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-200"
          >
            ↻ 새로고침
          </button>
        </div>

        {loading ? (
          <div className="py-16 text-center text-sm text-slate-400">
            시공 정보를 불러오는 중입니다...
          </div>
        ) : installationItems.length === 0 ? (
          <div className="mt-6 rounded-2xl bg-slate-50 p-10 text-center">
            <p className="text-3xl">🏠</p>
            <p className="mt-3 font-bold text-slate-700">
              현재 시공 목록이 없습니다.
            </p>
            <p className="mt-1 text-sm text-slate-400">
              계약완료 고객이 생기면 이곳에서 관리할 수 있습니다.
            </p>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            {installationItems.map(({ contract, customer }) => {
              if (!customer) return null;

              return (
                <div
                  key={contract.id}
                  className="rounded-2xl border border-slate-200 p-5"
                >
                  <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-lg font-black">
                          {customer.name}
                        </h4>

                        <StatusBadge status={contract.status} />
                      </div>

                      <div className="mt-3 grid gap-2 text-sm text-slate-500 sm:grid-cols-2">
                        <p>📞 {customer.phone || "-"}</p>
                        <p>📍 {customer.region || "-"}</p>
                        <p>🏠 {customer.service_type || "시공 내용 미입력"}</p>
                        <p>📅 계약일 {formatDate(contract.contract_date)}</p>
                      </div>

                      {contract.memo && (
                        <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm text-slate-600">
                          {contract.memo}
                        </div>
                      )}
                    </div>

                    <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
                      {contract.status === "계약완료" && (
                        <button
                          type="button"
                          disabled={savingId === contract.id}
                          onClick={() =>
                            void updateContractStatus(
                              contract.id,
                              "시공진행"
                            )
                          }
                          className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-black text-white hover:bg-blue-700 disabled:bg-blue-300"
                        >
                          🔨 시공 시작
                        </button>
                      )}

                      {contract.status === "시공진행" && (
                        <button
                          type="button"
                          disabled={savingId === contract.id}
                          onClick={() =>
                            void updateContractStatus(
                              contract.id,
                              "시공완료"
                            )
                          }
                          className="rounded-xl bg-emerald-600 px-5 py-3 text-sm font-black text-white hover:bg-emerald-700 disabled:bg-emerald-300"
                        >
                          ✅ 시공 완료
                        </button>
                      )}

                      {contract.status === "시공완료" && (
                        <div className="rounded-xl bg-emerald-50 px-5 py-3 text-sm font-black text-emerald-700">
                          시공 완료
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string | null }) {
  const label = status || "계약완료";

  const className =
    label === "시공완료"
      ? "bg-emerald-50 text-emerald-700"
      : label === "시공진행"
      ? "bg-blue-50 text-blue-700"
      : "bg-amber-50 text-amber-700";

  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-black ${className}`}
    >
      {label}
    </span>
  );
}

function SummaryCard({
  title,
  value,
  description,
  icon,
  active,
  onClick,
}: {
  title: string;
  value: string;
  description: string;
  icon: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-3xl border p-5 text-left shadow-sm transition hover:-translate-y-0.5 ${
        active
          ? "border-blue-200 bg-blue-50"
          : "border-slate-200 bg-white"
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm font-bold text-slate-500">{title}</p>
        <span className="text-xl">{icon}</span>
      </div>

      <p className="mt-4 text-2xl font-black">{value}</p>

      <p className="mt-2 text-xs text-slate-400">{description}</p>
    </button>
  );
}