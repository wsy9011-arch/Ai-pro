"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

import CustomerManager from "@/components/CustomerManager";
import OnlineRequestManager from "@/components/OnlineRequestManager";
import EstimateManager from "@/components/EstimateManager";
import ConsultationManager from "@/components/ConsultationManager";
import ContractManager from "@/components/ContractManager";
import SalesManager from "@/components/SalesManager";
import SettingsManager from "@/components/SettingsManager";
import PriceItemManager from "@/components/PriceItemManager";
import UnpaidManager from "@/components/UnpaidManager";
import InstallationManager from "@/components/InstallationManager";
import ASManager from "@/components/ASManager";
import MatchRequestManager from "@/components/MatchRequestManager";

const BUSINESS_TYPE_LABELS: Record<string, string> = {
  interior_film: "인테리어필름",
  wallpaper_flooring: "도배·장판",
  cleaning: "청소",
  air_conditioner: "에어컨",
  moving: "이사",
  demolition: "철거",
  auto_repair: "자동차 정비",
  sign_printing: "간판·인쇄",
  window_screen: "방충망·샷시",
  field_repair: "출장수리",
  plumbing: "설비·배관",
  electrical: "전기",
  painting: "도장·페인트",
  other: "기타",
};

type MenuItem = {
  icon: string;
  name: string;
  description: string;
};

function getMenus(businessType: string): MenuItem[] {
  const label =
    BUSINESS_TYPE_LABELS[businessType] || "내 업종";

  return [
    {
      icon: "🏠",
      name: "홈",
      description: `${label} 업무를 한곳에서 관리하세요.`,
    },
    {
      icon: "👥",
      name: "고객 관리",
      description: `${label} 고객 문의와 고객 정보를 관리하세요.`,
    },
    {
      icon: "🧾",
      name: "견적 관리",
      description: `${label} 등록 단가를 기준으로 AI 견적을 만들어보세요.`,
    },
    {
  icon: "🤝",
  name: "매칭 문의",
  description: `${label} 신규 고객 문의를 확인하고 수락하세요.`,
},
    {
      icon: "💬",
      name: "AI 상담",
      description: `${label} 고객에게 보낼 상담 답변을 빠르게 만들어보세요.`,
    },
    {
      icon: "📋",
      name: "계약 관리",
      description: `${label} 견적부터 계약 완료까지 관리하세요.`,
    },
    {
      icon: "💵",
      name: "미수금 관리",
      description: `${label} 계약금액과 입금액, 남은 미수금을 관리하세요.`,
    },
    {
      icon: "🛠️",
      name: "시공 관리",
      description: `${label} 계약 이후 시공 진행 상태를 관리하세요.`,
    },
    {
      icon: "🧰",
      name: "AS 관리",
      description: `${label} AS 접수와 처리 상태를 관리하세요.`,
    },
    {
      icon: "💰",
      name: "매출 관리",
      description: `${label} 견적과 계약 매출을 확인하세요.`,
    },
    {
      icon: "💳",
      name: "단가 관리",
      description: `내 ${label} 서비스 단가만 등록하고 관리하세요.`,
    },
    {
      icon: "⚙️",
      name: "설정",
      description: "업체정보와 계정을 관리하세요.",
    },
  ];
}

export default function Home() {
  const router = useRouter();

  const [authChecking, setAuthChecking] = useState(true);
  const [accountType, setAccountType] = useState<"business" | "customer">("business");

  const [activeMenu, setActiveMenu] = useState("홈");
  const [businessType, setBusinessType] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerRegion, setCustomerRegion] = useState("");
  const [customerService, setCustomerService] = useState("");
  const [customerInquiry, setCustomerInquiry] = useState("");
  const [customerUserId, setCustomerUserId] = useState("");
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function loadSessionAndProfile() {
      const {
        data: { session },
        error: sessionError,
      } = await supabase.auth.getSession();

      if (!mounted) return;

      if (sessionError || !session) {
        router.replace("/login");
        return;
      }

      /*
       * 로그인 시 저장된 account_type을 최우선으로 사용합니다.
       * 고객 계정은 business_profiles가 없어도 고객 화면으로 들어가야 합니다.
       */
      const metadataType =
        session.user.user_metadata?.account_type === "customer"
          ? "customer"
          : session.user.user_metadata?.account_type === "business"
            ? "business"
            : null;

      const { data: businessProfile } = await supabase
        .from("business_profiles")
        .select("business_name,owner_name,business_type")
        .eq("user_id", session.user.id)
        .maybeSingle();

      const { data: customerProfile } = await supabase
        .from("customers")
        .select("name,phone,region,service_type,inquiry")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (!mounted) return;

      /*
       * 판단 우선순위:
       * 1. auth user_metadata.account_type
       * 2. customers에 본인 user_id가 있으면 고객
       * 3. business_profiles가 있으면 사장님
       */
      const resolvedType: "business" | "customer" =
        businessProfile
          ? "business"
          : metadataType || (customerProfile ? "customer" : "business");

      setAccountType(resolvedType);
      setCustomerUserId(session.user.id);

      if (resolvedType === "customer") {
        setCustomerName(
          customerProfile?.name ||
            session.user.user_metadata?.name ||
            session.user.email?.split("@")[0] ||
            "고객님",
        );
        setCustomerPhone(customerProfile?.phone || "");
        setCustomerRegion(customerProfile?.region || "");
        setCustomerService(customerProfile?.service_type || "");
        setCustomerInquiry(customerProfile?.inquiry || "");
      } else {
        setBusinessName(businessProfile?.business_name || "");
        setOwnerName(
          businessProfile?.owner_name ||
            session.user.user_metadata?.name ||
            "",
        );
        setBusinessType(businessProfile?.business_type || "");
      }

      setAuthChecking(false);
    }

    void loadSessionAndProfile();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        router.replace("/login");
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [router]);

  useEffect(() => {
    if (accountType !== "business") return;

    function handleOpenEstimate() {
      setActiveMenu("견적 관리");
      setMoreOpen(false);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }

    window.addEventListener("open-estimate-manager", handleOpenEstimate);

    return () => {
      window.removeEventListener("open-estimate-manager", handleOpenEstimate);
    };
  }, [accountType]);

  function go(name: string) {
    setActiveMenu(name);
    setMoreOpen(false);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  if (authChecking) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f5f6f8]">
        <div className="rounded-2xl border border-slate-200 bg-white px-6 py-5 text-sm font-bold text-slate-500">
          로그인 상태를 확인하고 있습니다...
        </div>
      </main>
    );
  }

  if (accountType === "customer") {
    return (
      <CustomerHome
        name={customerName}
        phone={customerPhone}
        region={customerRegion}
        serviceType={customerService}
        inquiry={customerInquiry}
        userId={customerUserId}
        onLogout={async () => {
          await supabase.auth.signOut();
          router.replace("/login");
        }}
      />
    );
  }

  const businessLabel =
    BUSINESS_TYPE_LABELS[businessType] || "업종 미설정";

  const displayName = ownerName || "사장님";
  const menus = getMenus(businessType);

  return (
    <main className="min-h-screen bg-[#f5f6f8] text-slate-900">
      <div className="flex min-h-screen min-w-0">
        <aside className="hidden w-64 shrink-0 flex-col bg-slate-950 p-5 text-white md:flex">
          <button
            type="button"
            onClick={() => go("홈")}
            className="mb-8 text-left"
          >
            <div className="text-2xl font-black tracking-tight">
              견적<span className="text-blue-400">AI</span>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              사장님을 위한 AI 업무비서
            </p>
          </button>

          <nav className="space-y-1.5">
            {menus.map((menu) => (
              <button
                key={menu.name}
                type="button"
                onClick={() => go(menu.name)}
                className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm transition ${
                  activeMenu === menu.name
                    ? "bg-blue-600 font-bold text-white shadow-sm"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <span className="w-6 text-center text-base">{menu.icon}</span>
                <span>{menu.name}</span>
              </button>
            ))}
          </nav>

          <div className="mt-auto rounded-2xl bg-slate-900 p-4">
            <p className="text-xs text-slate-500">현재 업종</p>
            <p className="mt-1 font-bold text-white">{businessLabel}</p>
            <p className="mt-1 truncate text-xs text-slate-500">
              {businessName || "업체정보를 설정해주세요."}
            </p>
          </div>
        </aside>

        <section className="min-w-0 flex-1 overflow-x-hidden">
          <header className="flex h-20 items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-6 lg:px-10">
            <div>
              <p className="text-xs font-bold tracking-wide text-blue-600">
                AI QUOTE ASSISTANT
              </p>
              <h1 className="mt-1 text-xl font-black">{activeMenu}</h1>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden text-right sm:block">
                <p className="text-sm font-bold">{displayName}</p>
                <p className="text-xs text-slate-400">{businessLabel}</p>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-950 text-sm font-bold text-white">
                {displayName.slice(0, 1)}
              </div>
            </div>
          </header>

          <div className="p-5 pb-28 sm:p-7 lg:p-10 lg:pb-10">
            {activeMenu === "홈" && (
              <HomeMenu
                ownerName={displayName}
                businessName={businessName}
                businessLabel={businessLabel}
                menus={menus}
                onNavigate={go}
              />
            )}

            {activeMenu === "고객 관리" && (
              <>
                <OnlineRequestManager />
                <CustomerManager />
              </>
            )}

            {activeMenu === "견적 관리" && <EstimateManager />}
            {activeMenu === "매칭 문의" && <MatchRequestManager />}
            {activeMenu === "AI 상담" && <ConsultationManager />}
            {activeMenu === "계약 관리" && (
              <ContractManager onNavigate={go} />
            )}
            {activeMenu === "미수금 관리" && <UnpaidManager />}
            {activeMenu === "시공 관리" && <InstallationManager />}
            {activeMenu === "AS 관리" && <ASManager />}
            {activeMenu === "매출 관리" && <SalesManager onNavigate={go} />}
            {activeMenu === "단가 관리" && <PriceItemManager />}
            {activeMenu === "설정" && <SettingsManager />}
          </div>
        </section>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-slate-200 bg-white/95 px-2 pb-[env(safe-area-inset-bottom)] shadow-[0_-6px_24px_rgba(15,23,42,0.08)] backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-xl items-stretch justify-around">
          {menus.slice(0, 4).map((menu) => (
            <button
              key={menu.name}
              type="button"
              onClick={() => go(menu.name)}
              className={`flex min-w-0 flex-1 flex-col items-center gap-1 px-1 py-3 text-[11px] font-bold ${
                activeMenu === menu.name ? "text-blue-600" : "text-slate-400"
              }`}
            >
              <span className="text-lg leading-none">{menu.icon}</span>
              <span className="truncate">{menu.name}</span>
            </button>
          ))}

          <button
            type="button"
            onClick={() => setMoreOpen((value) => !value)}
            className={`flex min-w-0 flex-1 flex-col items-center gap-1 px-1 py-3 text-[11px] font-bold ${
              moreOpen ? "text-blue-600" : "text-slate-400"
            }`}
          >
            <span className="text-lg leading-none">☰</span>
            <span>더보기</span>
          </button>
        </div>
      </nav>

      {moreOpen && (
        <div className="fixed inset-x-3 bottom-24 z-50 rounded-3xl border border-slate-200 bg-white p-3 shadow-2xl md:hidden">
          <div className="grid grid-cols-2 gap-2">
            {menus.slice(4).map((menu) => (
              <button
                key={menu.name}
                type="button"
                onClick={() => go(menu.name)}
                className={`rounded-2xl p-4 text-left ${
                  activeMenu === menu.name
                    ? "bg-blue-50 text-blue-700"
                    : "bg-slate-50"
                }`}
              >
                <div className="text-xl">{menu.icon}</div>
                <p className="mt-2 text-sm font-black">{menu.name}</p>
                <p className="mt-1 text-[11px] leading-4 text-slate-400">
                  {menu.description}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}

function CustomerHome({
  name,
  phone,
  region,
  serviceType,
  inquiry,
  userId,
  onLogout,
}: {
  name: string;
  phone: string;
  region: string;
  serviceType: string;
  inquiry: string;
  userId: string;
  onLogout: () => void;
}) {
  type ServiceRequest = {
    id: string;
    business_type: string;
    service_type: string | null;
    name: string;
    phone: string;
    region: string;
    inquiry: string;
    status: string;
    created_at: string;
  };

  type CustomerEstimate = {
    id: string;
    user_id: string;
    customer_user_id: string | null;
    estimate_number: string | null;
    work_description: string | null;
    material_cost: number | null;
    labor_cost: number | null;
    other_cost: number | null;
    total_amount: number | null;
    status: string | null;
    created_at: string;
    sent_at: string | null;
  };

  const [requestOpen, setRequestOpen] = useState(false);
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loadingRequests, setLoadingRequests] = useState(true);
  const [receivedEstimates, setReceivedEstimates] = useState<CustomerEstimate[]>([]);
  const [loadingEstimates, setLoadingEstimates] = useState(true);
  const [estimateReplyingId, setEstimateReplyingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [formName, setFormName] = useState(name);
  const [formPhone, setFormPhone] = useState(phone);
  const [formRegion, setFormRegion] = useState(region);
  const [formBusinessType, setFormBusinessType] = useState("interior_film");
  const [formServiceType, setFormServiceType] = useState(serviceType);
  const [formInquiry, setFormInquiry] = useState(inquiry);

  const businessOptions = [
    ["interior_film", "인테리어필름"],
    ["wallpaper_flooring", "도배·장판"],
    ["cleaning", "청소"],
    ["air_conditioner", "에어컨"],
    ["moving", "이사"],
    ["demolition", "철거"],
    ["auto_repair", "자동차 정비"],
    ["sign_printing", "간판·인쇄"],
    ["window_screen", "방충망·샷시"],
    ["field_repair", "출장수리"],
    ["plumbing", "설비·배관"],
    ["electrical", "전기"],
    ["painting", "도장·페인트"],
    ["other", "기타"],
  ];

  useEffect(() => {
    setFormName(name);
    setFormPhone(phone);
    setFormRegion(region);
    setFormServiceType(serviceType);
    setFormInquiry(inquiry);
  }, [name, phone, region, serviceType, inquiry]);

  useEffect(() => {
    if (!userId) return;

    async function loadCustomerData() {
      setLoadingRequests(true);
      setLoadingEstimates(true);

      const { data: requestData, error: requestError } = await supabase
        .from("service_requests")
        .select(
          "id,business_type,service_type,name,phone,region,inquiry,status,created_at"
        )
        .eq("user_id", userId)
        .order("created_at", { ascending: false });

      if (requestError) {
        console.error("CUSTOMER REQUEST LOAD ERROR:", requestError);
        setRequests([]);
      } else {
        setRequests((requestData ?? []) as ServiceRequest[]);
      }

      const { data: estimateData, error: estimateError } = await supabase
        .from("estimates")
        .select(
          "id,user_id,customer_user_id,estimate_number,work_description,material_cost,labor_cost,other_cost,total_amount,status,created_at,sent_at"
        )
        .eq("customer_user_id", userId)
        .order("created_at", { ascending: false });

        console.log("CURRENT USER:", userId);
console.log("ESTIMATE DATA:", estimateData);
console.log("ESTIMATE ERROR:", estimateError);

      if (estimateError) {
        console.error("CUSTOMER ESTIMATE LOAD ERROR:", estimateError);
        setReceivedEstimates([]);
      } else {
      alert(`견적 개수: ${estimateData?.length ?? 0}`);

setReceivedEstimates((estimateData ?? []) as CustomerEstimate[]);
      }

      setLoadingRequests(false);
      setLoadingEstimates(false);
    }

    void loadCustomerData();
  }, [userId]);

  async function submitRequest() {
    if (!userId) {
      alert("로그인 정보를 확인할 수 없습니다.");
      return;
    }

    if (!formName.trim() || !formPhone.trim() || !formRegion.trim()) {
      alert("이름, 연락처, 지역을 입력해주세요.");
      return;
    }

    if (!formServiceType.trim() || !formInquiry.trim()) {
      alert("원하는 서비스와 문의 내용을 입력해주세요.");
      return;
    }

    setSaving(true);

    try {
      /*
       * 1. 고객 프로필을 최신 입력값으로 저장합니다.
       *    기존 고객이 있으면 업데이트하고, 없으면 새로 만듭니다.
       */
      const { data: existingCustomer, error: customerFindError } =
        await supabase
          .from("customers")
          .select("id")
          .eq("user_id", userId)
          .maybeSingle();

      if (customerFindError) {
        throw new Error(`고객 정보 확인 실패: ${customerFindError.message}`);
      }

      if (existingCustomer) {
        const { error: customerUpdateError } = await supabase
          .from("customers")
          .update({
            name: formName.trim(),
            phone: formPhone.trim(),
            region: formRegion.trim(),
            service_type: formServiceType.trim(),
            inquiry: formInquiry.trim(),
            status: "신규문의",
          })
          .eq("id", existingCustomer.id);

        if (customerUpdateError) {
          throw new Error(
            `고객 정보 저장 실패: ${customerUpdateError.message}`
          );
        }
      } else {
        const { error: customerInsertError } = await supabase
          .from("customers")
          .insert({
            user_id: userId,
            name: formName.trim(),
            phone: formPhone.trim(),
            region: formRegion.trim(),
            service_type: formServiceType.trim(),
            inquiry: formInquiry.trim(),
            status: "신규문의",
          });

        if (customerInsertError) {
          throw new Error(
            `고객 정보 저장 실패: ${customerInsertError.message}`
          );
        }
      }

      /*
       * 2. 업체 매칭의 출발점이 되는 온라인 문의를 생성합니다.
       */
      const { data: insertedRequest, error: requestError } = await supabase
        .from("service_requests")
        .insert({
          user_id: userId,
          business_type: formBusinessType,
          service_type: formServiceType.trim(),
          name: formName.trim(),
          phone: formPhone.trim(),
          region: formRegion.trim(),
          inquiry: formInquiry.trim(),
          status: "신규문의",
        })
        .select(
          "id,business_type,service_type,name,phone,region,inquiry,status,created_at"
        )
        .single();

      if (requestError) {
        throw new Error(`문의 등록 실패: ${requestError.message}`);
      }

      if (!insertedRequest) {
        throw new Error("문의 등록 결과를 확인할 수 없습니다.");
      }

      const { error: matchRequestError } = await supabase
  .from("match_requests")
  .insert({
    customer_user_id: userId,
    customer_name: formName.trim(),
    customer_phone: formPhone.trim(),
    region: formRegion.trim(),
    service_type: formServiceType.trim(),
    inquiry: formInquiry.trim(),
    status: "문의접수",
  });

if (matchRequestError) {
  throw new Error(
    `매칭 문의 등록 실패: ${matchRequestError.message}`
  );
}

      setRequests((current) => [
        insertedRequest as ServiceRequest,
        ...current,
      ]);

      setRequestOpen(false);
      setFormInquiry("");
      alert("문의가 등록되었습니다. 업체 매칭을 준비합니다.");
    } catch (error) {
      console.error("CUSTOMER REQUEST SAVE ERROR:", error);
      alert(
        error instanceof Error
          ? error.message
          : "문의 등록 중 오류가 발생했습니다."
      );
    } finally {
      setSaving(false);
    }
  }

  async function respondToEstimate(estimateId: string, nextStatus: "승인" | "거절") {
    const message =
      nextStatus === "승인"
        ? "이 견적을 승인하시겠습니까?"
        : "이 견적을 거절하시겠습니까?";

    if (!window.confirm(message)) return;

    setEstimateReplyingId(estimateId);

    try {
      const { data, error } = await supabase
        .from("estimates")
        .update({
          status: nextStatus,
          updated_at: new Date().toISOString(),
        })
        .eq("id", estimateId)
        .eq("customer_user_id", userId)
        .select(
          "id,user_id,customer_user_id,estimate_number,work_description,material_cost,labor_cost,other_cost,total_amount,status,created_at,sent_at"
        )
        .single();

      if (error) throw error;

      setReceivedEstimates((current) =>
        current.map((estimate) =>
          estimate.id === estimateId ? (data as CustomerEstimate) : estimate
        )
      );

      alert(nextStatus === "승인" ? "견적을 승인했습니다." : "견적을 거절했습니다.");
    } catch (error) {
      console.error("CUSTOMER ESTIMATE REPLY ERROR:", error);
      alert(
        error instanceof Error
          ? error.message
          : "견적 처리 중 오류가 발생했습니다."
      );
    } finally {
      setEstimateReplyingId(null);
    }
  }

  function formatEstimatePrice(value: number | null) {
    return `${Number(value || 0).toLocaleString("ko-KR")}원`;
  }

  function statusClass(status: string) {
    if (status === "신규문의") {
      return "bg-blue-50 text-blue-700";
    }

    if (status === "매칭완료" || status === "계약완료") {
      return "bg-emerald-50 text-emerald-700";
    }

    if (status === "보류" || status === "거절") {
      return "bg-red-50 text-red-600";
    }

    return "bg-slate-100 text-slate-600";
  }

  return (
    <main className="min-h-screen bg-[#f5f6f8] text-slate-900">
      <header className="flex h-20 items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-8 lg:px-12">
        <div>
          <p className="text-xs font-black tracking-wide text-emerald-600">
            견적AI CUSTOMER
          </p>
          <h1 className="mt-1 text-xl font-black">고객센터</h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden text-right sm:block">
            <p className="text-sm font-bold">{name}</p>
            <p className="text-xs text-emerald-600">고객</p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-600 text-sm font-black text-white">
            {name.slice(0, 1)}
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl p-5 pb-12 sm:p-8 lg:p-10">
        <section className="rounded-3xl border border-emerald-100 bg-white p-7 shadow-sm sm:p-10">
          <p className="text-sm font-black text-emerald-600">CUSTOMER</p>
          <h2 className="mt-2 text-3xl font-black sm:text-4xl">
            안녕하세요, {name}님 👋
          </h2>
          <p className="mt-3 text-sm leading-6 text-slate-500 sm:text-base">
            원하는 업체를 찾고 문의·견적·예약 정보를 한곳에서 관리하세요.
          </p>

          <button
            type="button"
            onClick={() => {
              setFormName(name);
              setFormPhone(phone);
              setFormRegion(region);
              setFormServiceType(serviceType);
              setFormInquiry("");
              setRequestOpen(true);
            }}
            className="mt-6 rounded-2xl bg-emerald-600 px-6 py-4 text-sm font-black text-white shadow-sm transition hover:bg-emerald-700"
          >
            + 업체에 문의하기
          </button>
        </section>

        <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["📝", "내 문의", "업체에 요청한 문의를 확인하세요."],
            ["💰", "받은 견적", "업체에서 보내온 견적을 확인하세요."],
            ["📅", "예약 정보", "상담 및 예약 일정을 확인하세요."],
            ["🏢", "매칭 업체", "연결된 업체 정보를 확인하세요."],
          ].map(([icon, title, description]) => (
            <button
              key={title}
              type="button"
              onClick={() => {
                if (title === "내 문의") {
                  document
                    .getElementById("customer-requests")
                    ?.scrollIntoView({ behavior: "smooth" });
                } else if (title === "받은 견적") {
                  document
                    .getElementById("customer-estimates")
                    ?.scrollIntoView({ behavior: "smooth" });
                } else {
                  alert(
                    title === "예약 정보"
                      ? "상담 또는 예약이 잡히면 이곳에 표시됩니다."
                      : "업체 매칭이 완료되면 연결된 업체 정보가 표시됩니다."
                  );
                }
              }}
              className="rounded-3xl border border-slate-200 bg-white p-6 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-200 hover:shadow-md"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-2xl">
                {icon}
              </div>
              <h3 className="mt-5 text-lg font-black">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                {description}
              </p>
            </button>
          ))}
        </section>

        <section
          id="customer-estimates"
          className="mt-6 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm sm:p-8"
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs font-black tracking-wide text-emerald-600">
                RECEIVED ESTIMATES
              </p>
              <h3 className="mt-1 text-xl font-black">받은 견적</h3>
              <p className="mt-2 text-sm text-slate-500">
                업체가 발송한 견적을 확인하고 승인 또는 거절할 수 있습니다.
              </p>
            </div>
            <div className="rounded-xl bg-emerald-50 px-4 py-2 text-sm font-black text-emerald-700">
              {receivedEstimates.length}건
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {loadingEstimates ? (
              <div className="rounded-2xl bg-slate-50 p-5 text-sm font-bold text-slate-400">
                받은 견적을 불러오는 중입니다...
              </div>
            ) : receivedEstimates.length === 0 ? (
              <div className="rounded-2xl bg-slate-50 p-7 text-center">
                <p className="font-black text-slate-700">아직 받은 견적이 없습니다.</p>
                <p className="mt-2 text-sm text-slate-400">
                  업체가 견적을 발송하면 이곳에 표시됩니다.
                </p>
              </div>
            ) : (
              receivedEstimates.map((estimate) => (
                <div
                  key={estimate.id}
                  className="rounded-2xl border border-emerald-100 bg-emerald-50/40 p-5"
                >
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-black text-slate-900">
                          {estimate.estimate_number || "견적서"}
                        </p>
                        <span className={`rounded-full px-2.5 py-1 text-xs font-black ${
                          estimate.status === "승인"
                            ? "bg-emerald-100 text-emerald-700"
                            : estimate.status === "거절"
                              ? "bg-red-100 text-red-600"
                              : "bg-blue-100 text-blue-700"
                        }`}>
                          {estimate.status || "작성중"}
                        </span>
                      </div>

                      <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-slate-700">
                        {estimate.work_description || "작업 내용이 없습니다."}
                      </p>

                      <p className="mt-3 text-xs text-slate-400">
                        {new Date(estimate.sent_at || estimate.created_at).toLocaleDateString("ko-KR")}
                      </p>
                    </div>

                    <p className="shrink-0 text-xl font-black text-emerald-700">
                      {formatEstimatePrice(estimate.total_amount)}
                    </p>
                  </div>

                  {estimate.status === "견적발송" && (
                    <div className="mt-5 grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        disabled={estimateReplyingId === estimate.id}
                        onClick={() => void respondToEstimate(estimate.id, "거절")}
                        className="rounded-xl border border-red-200 bg-white px-4 py-3 text-sm font-black text-red-600 disabled:opacity-50"
                      >
                        거절
                      </button>
                      <button
                        type="button"
                        disabled={estimateReplyingId === estimate.id}
                        onClick={() => void respondToEstimate(estimate.id, "승인")}
                        className="rounded-xl bg-emerald-600 px-4 py-3 text-sm font-black text-white disabled:opacity-50"
                      >
                        {estimateReplyingId === estimate.id ? "처리 중..." : "견적 승인"}
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </section>

        <section
          id="customer-requests"
          className="mt-6 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm sm:p-8"
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-black tracking-wide text-slate-400">
                MY REQUESTS
              </p>
              <h3 className="mt-1 text-xl font-black">내 문의</h3>
              <p className="mt-2 text-sm text-slate-500">
                내가 업체에 보낸 문의와 진행 상태를 확인하세요.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setRequestOpen(true)}
              className="rounded-xl bg-emerald-600 px-5 py-3 text-sm font-black text-white"
            >
              + 문의 등록
            </button>
          </div>

          <div className="mt-6 space-y-3">
            {loadingRequests ? (
              <div className="rounded-2xl bg-slate-50 p-5 text-sm font-bold text-slate-400">
                문의 내역을 불러오는 중입니다...
              </div>
            ) : requests.length === 0 ? (
              <div className="rounded-2xl bg-slate-50 p-7 text-center">
                <p className="font-black text-slate-700">등록된 문의가 없습니다.</p>
                <p className="mt-2 text-sm text-slate-400">
                  원하는 서비스를 입력하고 업체에 첫 문의를 보내보세요.
                </p>
              </div>
            ) : (
              requests.map((request) => (
                <div
                  key={request.id}
                  className="rounded-2xl border border-slate-100 bg-slate-50 p-5"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-black text-slate-900">
                          {request.service_type || "서비스 문의"}
                        </p>
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-black ${statusClass(
                            request.status
                          )}`}
                        >
                          {request.status}
                        </span>
                      </div>

                      <p className="mt-2 text-sm text-slate-500">
                        {request.region} ·{" "}
                        {businessOptions.find(
                          ([value]) => value === request.business_type
                        )?.[1] || request.business_type}
                      </p>

                      <p className="mt-3 text-sm leading-6 text-slate-700">
                        {request.inquiry}
                      </p>
                    </div>

                    <p className="shrink-0 text-xs text-slate-400">
                      {new Date(request.created_at).toLocaleDateString("ko-KR")}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="mt-6 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-black tracking-wide text-slate-400">
                MY INFORMATION
              </p>
              <h3 className="mt-1 text-xl font-black">내 고객 정보</h3>
            </div>
            <button
              type="button"
              onClick={onLogout}
              className="rounded-xl border border-red-200 bg-red-50 px-5 py-3 text-sm font-black text-red-600"
            >
              로그아웃
            </button>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <InfoRow label="이름" value={name || "-"} />
            <InfoRow label="연락처" value={phone || "-"} />
            <InfoRow label="지역" value={region || "-"} />
            <InfoRow label="서비스" value={serviceType || "-"} />
          </div>

          <div className="mt-3 rounded-2xl bg-slate-50 p-5">
            <p className="text-xs font-bold text-slate-400">최근 문의 내용</p>
            <p className="mt-2 text-sm leading-6 text-slate-700">
              {inquiry || "등록된 문의 내용이 없습니다."}
            </p>
          </div>
        </section>
      </div>

      {requestOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/50 p-4">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5 sm:px-8">
              <div>
                <p className="text-xs font-black tracking-wide text-emerald-600">
                  NEW SERVICE REQUEST
                </p>
                <h3 className="mt-1 text-2xl font-black">업체에 문의하기</h3>
              </div>

              <button
                type="button"
                onClick={() => setRequestOpen(false)}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-lg font-black text-slate-500"
              >
                ×
              </button>
            </div>

            <div className="space-y-5 p-6 sm:p-8">
              <div>
                <label className="text-sm font-black">이름 *</label>
                <input
                  value={formName}
                  onChange={(event) => setFormName(event.target.value)}
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-emerald-500"
                  placeholder="이름"
                />
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label className="text-sm font-black">연락처 *</label>
                  <input
                    value={formPhone}
                    onChange={(event) => setFormPhone(event.target.value)}
                    className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-emerald-500"
                    placeholder="010-0000-0000"
                  />
                </div>

                <div>
                  <label className="text-sm font-black">지역 *</label>
                  <input
                    value={formRegion}
                    onChange={(event) => setFormRegion(event.target.value)}
                    className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-emerald-500"
                    placeholder="예: 시흥"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-black">업종 *</label>
                <select
                  value={formBusinessType}
                  onChange={(event) => setFormBusinessType(event.target.value)}
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 outline-none focus:border-emerald-500"
                >
                  {businessOptions.map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-black">원하는 서비스 *</label>
                <input
                  value={formServiceType}
                  onChange={(event) => setFormServiceType(event.target.value)}
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-emerald-500"
                  placeholder="예: 싱크대 필름 시공"
                />
              </div>

              <div>
                <label className="text-sm font-black">문의 내용 *</label>
                <textarea
                  value={formInquiry}
                  onChange={(event) => setFormInquiry(event.target.value)}
                  rows={6}
                  className="mt-2 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-emerald-500"
                  placeholder="원하는 작업, 대략적인 수량, 희망 일정 등을 적어주세요."
                />
              </div>

              <div className="rounded-2xl bg-emerald-50 p-4 text-sm leading-6 text-emerald-800">
                문의를 등록하면 해당 지역과 업종에 맞는 업체 매칭을 준비합니다.
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setRequestOpen(false)}
                  className="flex-1 rounded-xl border border-slate-200 px-5 py-4 text-sm font-black text-slate-600"
                >
                  취소
                </button>

                <button
                  type="button"
                  disabled={saving}
                  onClick={submitRequest}
                  className="flex-1 rounded-xl bg-emerald-600 px-5 py-4 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {saving ? "등록 중..." : "문의 등록하기"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
      <p className="text-xs font-bold text-slate-400">{label}</p>
      <p className="mt-1 font-bold text-slate-900">{value}</p>
    </div>
  );
}

function HomeMenu({
  ownerName,
  businessName,
  businessLabel,
  menus,
  onNavigate,
}: {
  ownerName: string;
  businessName: string;
  businessLabel: string;
  menus: MenuItem[];
  onNavigate: (name: string) => void;
}) {
  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
        <p className="text-sm font-bold text-blue-600">견적AI</p>

        <h2 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
          안녕하세요, {ownerName} 👋
        </h2>

        <p className="mt-3 text-sm leading-6 text-slate-500 sm:text-base">
          {businessLabel} 업무에 필요한 기능만 빠르게 사용하세요.
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          <span className="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700">
            현재 업종 · {businessLabel}
          </span>

          {businessName && (
            <span className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-600">
              {businessName}
            </span>
          )}
        </div>
      </div>

      <div className="mb-6 rounded-2xl border border-sky-100 bg-sky-50 p-5">
        <p className="text-xs font-black tracking-wide text-sky-600">
          현재 적용 업종
        </p>

        <div className="mt-1 flex items-center justify-between gap-4">
          <p className="text-lg font-black text-slate-900">{businessLabel}</p>
          <p className="text-xs font-bold text-slate-500">
            견적·단가·AI 기능에 동일하게 적용됩니다.
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {menus.slice(1).map((menu) => (
          <button
            key={menu.name}
            type="button"
            onClick={() => onNavigate(menu.name)}
            className="group rounded-3xl border border-slate-200 bg-white p-6 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-md"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-50 text-2xl transition group-hover:bg-blue-50">
              {menu.icon}
            </div>

            <h3 className="mt-5 text-lg font-black">{menu.name}</h3>

            <p className="mt-2 text-sm leading-6 text-slate-500">
              {menu.description}
            </p>

            <p className="mt-5 text-sm font-black text-blue-600">
              바로가기 →
            </p>
          </button>
        ))}
      </div>

      <div className="mt-8 rounded-3xl bg-slate-950 p-6 text-white sm:p-8">
        <p className="text-xs font-bold tracking-widest text-blue-400">
          ONE STOP WORKFLOW
        </p>

        <h3 className="mt-2 text-2xl font-black">
          {businessLabel} 문의부터 견적·계약까지 한곳에서
        </h3>

        <div className="mt-6 grid gap-3 sm:grid-cols-4">
          {[
            ["01", "고객 문의", "문의 내용을 빠르게 기록"],
            ["02", "AI 견적", "내 단가표로 견적 계산"],
            ["03", "계약", "진행 상태를 한눈에 관리"],
            ["04", "매출", "완료된 거래를 관리"],
          ].map(([number, title, text]) => (
            <div key={number} className="rounded-2xl bg-white/5 p-4">
              <p className="text-xs font-bold text-blue-300">{number}</p>
              <p className="mt-2 font-black">{title}</p>
              <p className="mt-1 text-xs leading-5 text-slate-400">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}